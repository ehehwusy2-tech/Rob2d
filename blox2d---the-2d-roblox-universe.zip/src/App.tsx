import React, { useState, useEffect, useCallback } from 'react';
import { 
  GameMode, 
  AvatarConfig, 
  GearItem, 
  ChatMessage, 
  LeaderboardEntry, 
  Badge 
} from './types/game';
import { DEFAULT_AVATAR, GEAR_DEFINITIONS, INITIAL_BADGES, BOT_NAMES } from './data/robloxData';
import { Topbar } from './components/Topbar';
import { ChatBox } from './components/ChatBox';
import { BackpackHotbar } from './components/BackpackHotbar';
import { Leaderboard } from './components/Leaderboard';
import { AvatarShop } from './components/AvatarShop';
import { EscMenu } from './components/EscMenu';
import { EmoteWheel } from './components/EmoteWheel';
import { HowToPlayModal } from './components/HowToPlayModal';
import { GameSelectModal } from './components/GameSelectModal';
import { MobileControls } from './components/MobileControls';
import { GameCanvas } from './games/GameCanvas';
import { sounds } from './audio/soundEngine';
import confetti from 'canvas-confetti';

export default function App() {
  // Current Experience Mode
  const [currentMode, setCurrentMode] = useState<GameMode>('discover');

  // Avatar Configuration
  const [avatar, setAvatar] = useState<AvatarConfig>(() => {
    const saved = localStorage.getItem('blox2d_avatar');
    return saved ? JSON.parse(saved) : DEFAULT_AVATAR;
  });

  // Robux Currency
  const [robux, setRobux] = useState<number>(() => {
    const saved = localStorage.getItem('blox2d_robux');
    return saved ? parseInt(saved) : 350;
  });

  // Inventory & Hotbar (starts with Classic Linked Sword)
  const [inventory, setInventory] = useState<GearItem[]>([
    GEAR_DEFINITIONS.sword,
    GEAR_DEFINITIONS.speed_coil,
  ]);
  const [equippedGear, setEquippedGear] = useState<GearItem | null>(GEAR_DEFINITIONS.sword);

  // Unlocked Catalog items
  const [unlockedItemIds, setUnlockedItemIds] = useState<string[]>([
    'hat_bacon',
    'face_smile',
    'acc_none',
    'gear_sword',
  ]);

  // Badges collection
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);

  // UI Modals & Panels
  const [isEscMenuOpen, setIsEscMenuOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isEmotesOpen, setIsEmotesOpen] = useState(false);
  const [isBackpackOpen, setIsBackpackOpen] = useState(true);
  const [isAvatarShopOpen, setIsAvatarShopOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Mobile controls state
  const [mobileLeft, setMobileLeft] = useState(false);
  const [mobileRight, setMobileRight] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  // Active Emote triggered on local avatar
  const [activeEmote, setActiveEmote] = useState<string | null>(null);

  // Chat messages
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'SYSTEM',
      text: 'Welcome to Blox2D! Play Natural Disaster, Tower of Hell, Blox Tycoon, and SFOTH.',
      isSystem: true,
      timestamp: '12:00',
    },
    {
      id: 'm2',
      sender: 'Builderman',
      text: 'Have fun exploring the 2D universe! Type /help for chat commands or /robux for free coins!',
      color: '#38bdf8',
      timestamp: '12:01',
    },
  ]);

  // Leaderboard data
  const [leaderboardEntries, setLeaderboardEntries] = useState<LeaderboardEntry[]>([
    {
      id: 'local',
      name: 'You',
      avatar,
      robux,
      wins: 0,
      kills: 0,
      ping: 32,
      isLocal: true,
    },
    ...BOT_NAMES.slice(0, 5).map((name, idx) => ({
      id: `bot_${idx}`,
      name,
      avatar: DEFAULT_AVATAR,
      robux: 120 + idx * 450,
      wins: Math.floor(Math.random() * 8) + 1,
      kills: Math.floor(Math.random() * 6),
      ping: 35 + idx * 8,
    })),
  ]);

  // Save Avatar and Robux to LocalStorage
  useEffect(() => {
    localStorage.setItem('blox2d_avatar', JSON.stringify(avatar));
  }, [avatar]);

  useEffect(() => {
    localStorage.setItem('blox2d_robux', robux.toString());
  }, [robux]);

  // Touch device detection
  useEffect(() => {
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      setIsTouchDevice(true);
    }
  }, []);

  // Global Keyboard Shortcuts (Esc, Tab, B)
  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT') return;

      if (e.key === 'Escape') {
        e.preventDefault();
        sounds.playClick();
        setIsEscMenuOpen((prev) => !prev);
      } else if (e.key === 'Tab') {
        e.preventDefault();
        sounds.playClick();
        setIsLeaderboardOpen((prev) => !prev);
      } else if (e.key === 'b' || e.key === 'B') {
        e.preventDefault();
        sounds.playClick();
        setIsEmotesOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleGlobalKeys);
    return () => window.removeEventListener('keydown', handleGlobalKeys);
  }, []);

  // Sync avatar to leaderboard
  useEffect(() => {
    setLeaderboardEntries((prev) =>
      prev.map((entry) => (entry.isLocal ? { ...entry, avatar, robux } : entry))
    );
  }, [avatar, robux]);

  // Spend Robux helper
  const handleSpendRobux = useCallback(
    (amount: number): boolean => {
      if (robux >= amount) {
        setRobux((r) => r - amount);
        return true;
      }
      return false;
    },
    [robux]
  );

  // Add Robux helper
  const handleAddRobux = useCallback((amount: number) => {
    setRobux((r) => r + amount);
  }, []);

  // Unlock Badge helper
  const handleUnlockBadge = useCallback(
    (badgeId: string) => {
      setBadges((prev) =>
        prev.map((b) => {
          if (b.id === badgeId && !b.unlocked) {
            sounds.playWinFanfare();
            confetti({ particleCount: 50, spread: 60 });
            setChatMessages((msgs) => [
              ...msgs,
              {
                id: `${Date.now()}_badge`,
                sender: 'SYSTEM',
                text: `🏆 BADGE UNLOCKED: [${b.name}]!`,
                isSystem: true,
                timestamp: 'now',
              },
            ]);
            return { ...b, unlocked: true, unlockedAt: 'Just now' };
          }
          return b;
        })
      );
    },
    []
  );

  // Add Kill helper
  const handleAddKill = useCallback(() => {
    setLeaderboardEntries((prev) =>
      prev.map((entry) => (entry.isLocal ? { ...entry, kills: entry.kills + 1 } : entry))
    );
  }, []);

  // Add Win helper
  const handleAddWin = useCallback(() => {
    setLeaderboardEntries((prev) =>
      prev.map((entry) => (entry.isLocal ? { ...entry, wins: entry.wins + 1 } : entry))
    );
  }, []);

  // New Chat Message
  const handleNewChatMessage = useCallback(
    (sender: string, text: string, color?: string) => {
      setChatMessages((prev) => [
        ...prev.slice(-30),
        {
          id: `${Date.now()}_${Math.random()}`,
          sender,
          text,
          color,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    },
    []
  );

  // Add Gear to Inventory
  const handleAddGearToInventory = useCallback(
    (newGear: GearItem) => {
      setInventory((prev) => {
        if (prev.some((g) => g.id === newGear.id)) {
          return prev;
        }
        const nextSlot = prev.length + 1;
        return [...prev, { ...newGear, slot: nextSlot <= 5 ? nextSlot : 5 }];
      });
      setEquippedGear(newGear);
      handleUnlockBadge('fashion_icon');
    },
    [handleUnlockBadge]
  );

  // Reset Character handler
  const handleResetCharacter = useCallback(() => {
    sounds.playOof();
    setActiveEmote('ragdoll');
    setIsEscMenuOpen(false);
  }, []);

  // Sound toggle
  const handleToggleMute = useCallback(() => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    sounds.setMuted(nextMuted);
  }, [isMuted]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-neutral-950 flex flex-col font-sans select-none">
      {/* Topbar */}
      <Topbar
        currentMode={currentMode}
        onSelectMode={(m) => setCurrentMode(m)}
        onToggleEscMenu={() => setIsEscMenuOpen(!isEscMenuOpen)}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        isChatOpen={isChatOpen}
        onToggleLeaderboard={() => setIsLeaderboardOpen(!isLeaderboardOpen)}
        isLeaderboardOpen={isLeaderboardOpen}
        onToggleEmotes={() => setIsEmotesOpen(!isEmotesOpen)}
        isEmotesOpen={isEmotesOpen}
        onToggleBackpack={() => setIsBackpackOpen(!isBackpackOpen)}
        isBackpackOpen={isBackpackOpen}
        robux={robux}
        onClaimDailyRobux={() => {
          sounds.playCoin();
          handleAddRobux(150);
          confetti({ particleCount: 30, spread: 60 });
        }}
        canClaimDaily={true}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenAvatarShop={() => setIsAvatarShopOpen(true)}
        onOpenHowToPlay={() => setIsHowToPlayOpen(true)}
      />

      {/* Main Viewport */}
      <main className="relative flex-1 w-full h-full flex items-center justify-center overflow-hidden bg-neutral-950">
        {currentMode === 'discover' ? (
          <div className="w-full h-full overflow-y-auto">
            <GameSelectModal
              onSelectGame={(m) => {
                setCurrentMode(m);
                sounds.playWinFanfare();
              }}
              onOpenAvatarShop={() => setIsAvatarShopOpen(true)}
              robux={robux}
            />
          </div>
        ) : (
          <GameCanvas
            mode={currentMode}
            avatar={avatar}
            equippedGear={equippedGear}
            onSelectGear={setEquippedGear}
            robux={robux}
            onAddRobux={handleAddRobux}
            onUnlockBadge={handleUnlockBadge}
            onAddKill={handleAddKill}
            onAddWin={handleAddWin}
            onNewChatMessage={handleNewChatMessage}
            localPlayerEmote={activeEmote}
            onClearEmote={() => setActiveEmote(null)}
            mobileLeft={mobileLeft}
            mobileRight={mobileRight}
          />
        )}
      </main>

      {/* Roblox Chat Window */}
      <ChatBox
        isOpen={isChatOpen && currentMode !== 'discover'}
        messages={chatMessages}
        onSendMessage={(txt) => handleNewChatMessage('You', txt, '#38bdf8')}
        onTriggerEmote={(em) => setActiveEmote(em)}
        onAddRobux={handleAddRobux}
      />

      {/* Backpack Hotbar [1] [2] [3] [4] [5] */}
      {currentMode !== 'discover' && (
        <BackpackHotbar
          isOpen={isBackpackOpen}
          inventory={inventory}
          equippedGear={equippedGear}
          onSelectGear={setEquippedGear}
        />
      )}

      {/* Leaderboard Playerlist (Tab) */}
      <Leaderboard
        isOpen={isLeaderboardOpen}
        entries={leaderboardEntries}
        currentMode={currentMode}
      />

      {/* Emote Wheel Modal */}
      <EmoteWheel
        isOpen={isEmotesOpen}
        onSelectEmote={(em) => {
          setActiveEmote(em);
          handleNewChatMessage('You', `/e ${em}`, '#fbbf24');
        }}
        onClose={() => setIsEmotesOpen(false)}
      />

      {/* Avatar Shop & Catalog Modal */}
      {isAvatarShopOpen && (
        <AvatarShop
          avatar={avatar}
          onUpdateAvatar={setAvatar}
          robux={robux}
          onSpendRobux={handleSpendRobux}
          onAddRobux={handleAddRobux}
          unlockedItemIds={unlockedItemIds}
          onUnlockItem={(id) => setUnlockedItemIds((prev) => [...prev, id])}
          badges={badges}
          onAddGearToInventory={handleAddGearToInventory}
          onClose={() => setIsAvatarShopOpen(false)}
        />
      )}

      {/* Esc Menu */}
      <EscMenu
        isOpen={isEscMenuOpen}
        onResume={() => setIsEscMenuOpen(false)}
        onResetCharacter={handleResetCharacter}
        onLeaveToDiscover={() => {
          setIsEscMenuOpen(false);
          setCurrentMode('discover');
        }}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* How to Play Modal */}
      <HowToPlayModal
        isOpen={isHowToPlayOpen}
        onClose={() => setIsHowToPlayOpen(false)}
      />

      {/* Mobile Touch Controls */}
      {currentMode !== 'discover' && (
        <MobileControls
          onMoveLeft={setMobileLeft}
          onMoveRight={setMobileRight}
          onJump={() => {
            const upEvent = new KeyboardEvent('keydown', { code: 'Space', key: ' ' });
            window.dispatchEvent(upEvent);
          }}
          onAction={() => {
            const actionEvent = new KeyboardEvent('keydown', { code: 'KeyZ', key: 'z' });
            window.dispatchEvent(actionEvent);
          }}
          onDash={() => {
            const dashEvent = new KeyboardEvent('keydown', { code: 'ShiftLeft', key: 'Shift' });
            window.dispatchEvent(dashEvent);
          }}
        />
      )}
    </div>
  );
}
