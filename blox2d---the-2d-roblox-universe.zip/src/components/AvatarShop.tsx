import React, { useState, useRef, useEffect } from 'react';
import { AvatarConfig, CatalogItem, Badge, GearItem } from '../types/game';
import { CATALOG_ITEMS, GEAR_DEFINITIONS } from '../data/robloxData';
import { drawAvatar } from '../utils/avatarDrawer';
import { sounds } from '../audio/soundEngine';
import confetti from 'canvas-confetti';
import { Sparkles, ShoppingBag, Check, Palette, Award, X, PlusCircle } from 'lucide-react';

interface AvatarShopProps {
  avatar: AvatarConfig;
  onUpdateAvatar: (newAvatar: AvatarConfig) => void;
  robux: number;
  onSpendRobux: (amount: number) => boolean;
  onAddRobux: (amount: number) => void;
  unlockedItemIds: string[];
  onUnlockItem: (itemId: string) => void;
  badges: Badge[];
  onAddGearToInventory: (gear: GearItem) => void;
  onClose: () => void;
}

const ROBLOX_COLORS = [
  { name: 'Bright Yellow (Classic)', hex: '#fde047' },
  { name: 'Bright Blue (Classic)', hex: '#0284c7' },
  { name: 'Bright Green (Classic)', hex: '#16a34a' },
  { name: 'Bright Red', hex: '#dc2626' },
  { name: 'Black', hex: '#18181b' },
  { name: 'White', hex: '#f8fafc' },
  { name: 'Bright Orange', hex: '#ea580c' },
  { name: 'Medium Stone Grey', hex: '#64748b' },
  { name: 'Royal Purple', hex: '#9333ea' },
  { name: 'Hot Pink', hex: '#ec4899' },
  { name: 'Teal', hex: '#0d9488' },
  { name: 'Tan Skin', hex: '#fed7aa' },
];

export const AvatarShop: React.FC<AvatarShopProps> = ({
  avatar,
  onUpdateAvatar,
  robux,
  onSpendRobux,
  onAddRobux,
  unlockedItemIds,
  onUnlockItem,
  badges,
  onAddGearToInventory,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'colors' | 'badges'>('catalog');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedBodyPart, setSelectedBodyPart] = useState<'skin' | 'torso' | 'legs'>('skin');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Live avatar canvas animation loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;
    const render = () => {
      time += 0.03;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw subtle grid platform pedestal
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.ellipse(canvas.width / 2, canvas.height - 24, 50, 14, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#38bdf844';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      const dummyPlayer = {
        id: 'preview',
        name: 'You',
        isLocal: true,
        x: canvas.width / 2 - 12,
        y: canvas.height - 76,
        vx: 0,
        vy: 0,
        width: 24,
        height: 48,
        grounded: true,
        hp: 100,
        maxHp: 100,
        avatar,
        equippedGear: null,
        facing: 'right' as const,
        currentEmote: 'wave',
        emoteTimer: 0,
        chatBubble: null,
        chatTimer: 0,
        kills: 0,
        isAlive: true,
        invincibleTimer: 0,
        lungeTimer: 0,
        walkFrame: 0,
      };

      drawAvatar(ctx, dummyPlayer, time);
      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [avatar]);

  const handleBuyOrEquip = (item: CatalogItem) => {
    const isUnlocked = unlockedItemIds.includes(item.id) || item.price === 0;

    if (!isUnlocked) {
      if (robux < item.price) {
        sounds.playOof();
        alert(`You need ${item.price - robux} more Robux to purchase this item! Click '+ Free' in the topbar or claim below!`);
        return;
      }
      const success = onSpendRobux(item.price);
      if (success) {
        onUnlockItem(item.id);
        sounds.playCoin();
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
        equipItem(item);
      }
    } else {
      equipItem(item);
    }
  };

  const equipItem = (item: CatalogItem) => {
    sounds.playClick();
    if (item.category === 'hat') {
      onUpdateAvatar({ ...avatar, hat: avatar.hat === item.value ? 'none' : item.value });
    } else if (item.category === 'face') {
      onUpdateAvatar({ ...avatar, face: item.value });
    } else if (item.category === 'accessory') {
      onUpdateAvatar({ ...avatar, accessory: avatar.accessory === item.value ? 'none' : item.value });
    } else if (item.category === 'gear') {
      const gearDef = GEAR_DEFINITIONS[item.value];
      if (gearDef) {
        onAddGearToInventory(gearDef);
      }
    }
  };

  const filteredItems = CATALOG_ITEMS.filter((item) => {
    if (categoryFilter === 'all') return true;
    return item.category === categoryFilter;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 select-none animate-fade-in">
      <div className="bg-neutral-900 border border-white/15 rounded-2xl w-full max-w-5xl h-[90vh] max-h-[750px] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3.5 bg-neutral-800/90 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">Avatar Shop & Catalog</h2>
              <p className="text-xs text-neutral-400">Customize your 2D blocky character and gear</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Robux Pill */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-950 border border-emerald-500/40">
              <div className="w-3.5 h-3.5 bg-emerald-500 rounded-xs rotate-45 flex items-center justify-center">
                <span className="text-[9px] font-black text-neutral-900 -rotate-45 leading-none">R$</span>
              </div>
              <span className="text-sm font-bold text-emerald-400">{robux.toLocaleString()}</span>
              <button
                onClick={() => {
                  sounds.playCoin();
                  onAddRobux(250);
                  confetti({ particleCount: 30, spread: 50 });
                }}
                className="ml-1 text-xs font-bold text-amber-300 hover:text-amber-200 flex items-center gap-1 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>+250 Free</span>
              </button>
            </div>

            <button
              onClick={() => {
                sounds.playClick();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs (Functional interactive tabs) */}
        <div className="px-5 py-2.5 bg-neutral-800/50 border-b border-white/5 flex items-center gap-2">
          <button
            onClick={() => {
              sounds.playClick();
              setActiveTab('catalog');
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'catalog'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Catalog Items</span>
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setActiveTab('colors');
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'colors'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Body Colors & Skin</span>
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setActiveTab('badges');
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'badges'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>My Badges ({badges.filter((b) => b.unlocked).length})</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left Column: Live Avatar Mannequin */}
          <div className="w-full md:w-72 bg-neutral-950/60 p-4 border-b md:border-b-0 md:border-r border-white/10 flex flex-col items-center justify-center shrink-0">
            <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
              Character Preview
            </span>
            <div className="relative w-48 h-56 bg-neutral-900 rounded-xl border border-white/10 shadow-inner flex items-center justify-center overflow-hidden">
              <canvas ref={canvasRef} width={180} height={210} className="w-full h-full" />
            </div>

            {/* Current Equipped Specs */}
            <div className="mt-3 text-center space-y-1">
              <div className="text-xs text-neutral-300">
                <span className="text-neutral-500">Hat: </span>
                <span className="font-semibold capitalize text-sky-400">{avatar.hat}</span>
              </div>
              <div className="text-xs text-neutral-300">
                <span className="text-neutral-500">Face: </span>
                <span className="font-semibold capitalize text-amber-400">{avatar.face}</span>
              </div>
              <div className="text-xs text-neutral-300">
                <span className="text-neutral-500">Accessory: </span>
                <span className="font-semibold capitalize text-rose-400">{avatar.accessory}</span>
              </div>
            </div>

            {/* Quick Reset to Default Noob */}
            <button
              onClick={() => {
                sounds.playClick();
                onUpdateAvatar({
                  skinColor: '#fde047',
                  torsoColor: '#0284c7',
                  leftLegColor: '#16a34a',
                  rightLegColor: '#16a34a',
                  hat: 'none',
                  face: 'smile',
                  accessory: 'none',
                  animStyle: 'classic',
                });
              }}
              className="mt-3 px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs rounded-md border border-white/10 transition-colors"
            >
              Reset to Classic Noob
            </button>
          </div>

          {/* Right Column: Catalog Grid / Body Colors / Badges */}
          <div className="flex-1 flex flex-col overflow-hidden bg-neutral-900/60 p-4 sm:p-5">
            {activeTab === 'catalog' && (
              <>
                {/* Category Filters */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-2 scrollbar-none">
                  {['all', 'hat', 'face', 'accessory', 'gear'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => {
                        sounds.playClick();
                        setCategoryFilter(cat);
                      }}
                      className={`px-3 py-1 text-xs font-semibold rounded-md capitalize transition-colors ${
                        categoryFilter === cat
                          ? 'bg-neutral-100 text-neutral-900 shadow-sm'
                          : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Items Grid */}
                <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pr-1">
                  {filteredItems.map((item) => {
                    const isUnlocked = unlockedItemIds.includes(item.id) || item.price === 0;
                    const isEquipped =
                      (item.category === 'hat' && avatar.hat === item.value) ||
                      (item.category === 'face' && avatar.face === item.value) ||
                      (item.category === 'accessory' && avatar.accessory === item.value);

                    return (
                      <div
                        key={item.id}
                        className={`p-3 rounded-xl bg-neutral-800/90 border transition-all flex flex-col justify-between ${
                          isEquipped
                            ? 'border-sky-500 shadow-[0_0_12px_rgba(56,189,248,0.3)]'
                            : 'border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div>
                          {/* Item Card Banner / Icon */}
                          <div
                            className="w-full h-20 rounded-lg flex items-center justify-center shadow-inner mb-2"
                            style={{ backgroundColor: `${item.iconColor || '#3b82f6'}22` }}
                          >
                            <div
                              className="w-10 h-10 rounded-lg flex items-center justify-center text-xl shadow-xs"
                              style={{ backgroundColor: item.iconColor || '#3b82f6' }}
                            >
                              {item.category === 'gear' ? '⚔️' : item.category === 'hat' ? '🎩' : item.category === 'face' ? '🙂' : '✨'}
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-xs font-bold text-white truncate">{item.name}</span>
                            <span className="text-[10px] text-neutral-400 font-medium capitalize shrink-0">
                              {item.rarity}
                            </span>
                          </div>

                          <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed mb-3">
                            {item.description}
                          </p>
                        </div>

                        {/* Action Button */}
                        <button
                          onClick={() => handleBuyOrEquip(item)}
                          className={`w-full py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                            isEquipped
                              ? 'bg-neutral-700 text-sky-400 border border-sky-400/40'
                              : isUnlocked
                              ? 'bg-sky-600 hover:bg-sky-500 text-white'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          }`}
                        >
                          {isEquipped ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Equipped</span>
                            </>
                          ) : isUnlocked ? (
                            <span>Equip</span>
                          ) : (
                            <>
                              <div className="w-3 h-3 bg-emerald-300 rounded-2xs rotate-45 flex items-center justify-center">
                                <span className="text-[8px] font-black text-neutral-900 -rotate-45">R$</span>
                              </div>
                              <span>Buy R$ {item.price}</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {activeTab === 'colors' && (
              <div className="flex-1 overflow-y-auto space-y-4">
                {/* Body Part Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-neutral-300">Choose Part:</span>
                  {(['skin', 'torso', 'legs'] as const).map((part) => (
                    <button
                      key={part}
                      onClick={() => {
                        sounds.playClick();
                        setSelectedBodyPart(part);
                      }}
                      className={`px-3 py-1 text-xs font-semibold rounded-md capitalize transition-colors ${
                        selectedBodyPart === part
                          ? 'bg-sky-600 text-white'
                          : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                      }`}
                    >
                      {part === 'skin' ? 'Head & Arms' : part === 'torso' ? 'Torso Shirt' : 'Legs & Pants'}
                    </button>
                  ))}
                </div>

                {/* Color Swatches Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {ROBLOX_COLORS.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => {
                        sounds.playClick();
                        if (selectedBodyPart === 'skin') {
                          onUpdateAvatar({ ...avatar, skinColor: c.hex });
                        } else if (selectedBodyPart === 'torso') {
                          onUpdateAvatar({ ...avatar, torsoColor: c.hex });
                        } else {
                          onUpdateAvatar({ ...avatar, leftLegColor: c.hex, rightLegColor: c.hex });
                        }
                      }}
                      className="p-3 bg-neutral-800/80 hover:bg-neutral-700 rounded-xl border border-white/10 flex items-center gap-3 transition-colors text-left"
                    >
                      <div
                        className="w-7 h-7 rounded-md border border-white/20 shrink-0 shadow-xs"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="text-xs font-semibold text-neutral-200">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'badges' && (
              <div className="flex-1 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-3">
                {badges.map((b) => (
                  <div
                    key={b.id}
                    className={`p-3 rounded-xl border flex items-center gap-3 ${
                      b.unlocked
                        ? 'bg-emerald-950/20 border-emerald-500/30'
                        : 'bg-neutral-800/40 border-white/5 opacity-60'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center text-xl shrink-0">
                      {b.icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{b.name}</span>
                        {b.unlocked && (
                          <span className="text-[10px] text-emerald-400 font-bold">UNLOCKED</span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400 leading-snug">{b.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
