import React, { useEffect } from 'react';
import { GearItem } from '../types/game';
import { sounds } from '../audio/soundEngine';

interface BackpackHotbarProps {
  isOpen: boolean;
  inventory: GearItem[];
  equippedGear: GearItem | null;
  onSelectGear: (gear: GearItem | null) => void;
}

export const BackpackHotbar: React.FC<BackpackHotbarProps> = ({
  isOpen,
  inventory,
  equippedGear,
  onSelectGear,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid if typing in input
      if (document.activeElement?.tagName === 'INPUT') return;

      const key = parseInt(e.key);
      if (key >= 1 && key <= 5) {
        const item = inventory.find((i) => i.slot === key);
        if (item) {
          sounds.playClick();
          if (equippedGear?.id === item.id) {
            onSelectGear(null); // Unequip
          } else {
            onSelectGear(item);
          }
        } else if (key === 1 && equippedGear) {
          onSelectGear(null);
        }
      } else if (e.key === '`') {
        // Toggle unequip
        onSelectGear(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [inventory, equippedGear, onSelectGear]);

  if (!isOpen) return null;

  // Render 5 hotbar slots
  const slots = [1, 2, 3, 4, 5];

  return (
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 p-1.5 bg-neutral-900/90 backdrop-blur-md rounded-xl border border-white/15 shadow-2xl pointer-events-auto">
      {slots.map((slotNum) => {
        const item = inventory.find((i) => i.slot === slotNum);
        const isEquipped = equippedGear?.id === item?.id;

        return (
          <button
            key={slotNum}
            onClick={() => {
              sounds.playClick();
              if (!item) return;
              if (isEquipped) {
                onSelectGear(null);
              } else {
                onSelectGear(item);
              }
            }}
            disabled={!item}
            className={`relative w-12 h-12 sm:w-14 sm:h-14 rounded-lg flex flex-col items-center justify-center transition-all ${
              item
                ? isEquipped
                  ? 'bg-sky-600/50 border-2 border-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.5)] scale-105'
                  : 'bg-neutral-800 hover:bg-neutral-700/80 border border-white/10 active:scale-95'
                : 'bg-neutral-900/60 border border-white/5 opacity-40 cursor-default'
            }`}
          >
            {/* Slot Number Label */}
            <span className="absolute top-1 left-1.5 text-[10px] font-mono font-bold text-neutral-300">
              {slotNum}
            </span>

            {item ? (
              <>
                <span className="text-xl sm:text-2xl mt-1 select-none">{item.icon}</span>
                <span className="text-[9px] font-semibold text-neutral-200 truncate max-w-[48px] px-0.5">
                  {item.name.split(' ')[0]}
                </span>
              </>
            ) : null}
          </button>
        );
      })}
    </div>
  );
};
