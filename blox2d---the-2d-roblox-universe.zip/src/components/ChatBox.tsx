import React, { useState, useEffect, useRef } from 'react';
import { Send, Smile } from 'lucide-react';
import { ChatMessage } from '../types/game';
import { sounds } from '../audio/soundEngine';

interface ChatBoxProps {
  isOpen: boolean;
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onTriggerEmote: (emote: string) => void;
  onAddRobux: (amount: number) => void;
}

const BAD_WORDS = ['stupid', 'hate', 'noob', 'idiot', 'die', 'kill', 'loser', 'suck', 'trash'];

export const ChatBox: React.FC<ChatBoxProps> = ({
  isOpen,
  messages,
  onSendMessage,
  onTriggerEmote,
  onAddRobux,
}) => {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  // Keyboard shortcut '/' to focus chat
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;

    sounds.playClick();

    // Check for chat commands
    if (trimmed.startsWith('/e ') || trimmed === '/dance' || trimmed === '/wave' || trimmed === '/cheer') {
      const emote = trimmed.replace('/e ', '').replace('/', '').toLowerCase();
      onTriggerEmote(emote);
      onSendMessage(trimmed);
      setInput('');
      return;
    }

    if (trimmed === '/reset' || trimmed === '/oof') {
      onTriggerEmote('ragdoll');
      sounds.playOof();
      onSendMessage('*resets character*');
      setInput('');
      return;
    }

    if (trimmed === '/robux') {
      onAddRobux(500);
      sounds.playWinFanfare();
      onSendMessage('[SYSTEM]: Cheat code accepted! +500 Robux added to your account.');
      setInput('');
      return;
    }

    if (trimmed === '/help') {
      onSendMessage('[SYSTEM]: Commands: /e dance, /e wave, /e cheer, /reset, /robux');
      setInput('');
      return;
    }

    // Classic Roblox Filter simulation!
    let filtered = trimmed;
    BAD_WORDS.forEach((word) => {
      const regex = new RegExp(`\\b${word}\\b`, 'gi');
      filtered = filtered.replace(regex, '####');
    });

    onSendMessage(filtered);
    setInput('');
  };

  return (
    <div className="absolute top-12 left-3 z-30 w-72 sm:w-84 max-w-[calc(100vw-24px)] bg-neutral-900/85 backdrop-blur-md rounded-lg border border-white/10 shadow-2xl overflow-hidden flex flex-col pointer-events-auto">
      {/* Header */}
      <div className="px-3 py-1.5 bg-neutral-800/80 border-b border-white/10 flex items-center justify-between text-xs font-semibold text-neutral-300">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Robloxian Chat</span>
        </div>
        <span className="text-[10px] text-neutral-400">Press / to talk</span>
      </div>

      {/* Messages Scroll Area */}
      <div
        ref={scrollRef}
        className="h-44 overflow-y-auto p-2 space-y-1.5 text-xs font-medium leading-relaxed"
      >
        {messages.map((m) => (
          <div key={m.id} className="break-words">
            {m.isSystem ? (
              <span className="text-amber-400 font-semibold">{m.text}</span>
            ) : (
              <>
                <span
                  className="font-bold cursor-pointer hover:underline"
                  style={{ color: m.color || '#38bdf8' }}
                >
                  [{m.sender}]:
                </span>{' '}
                <span className="text-neutral-100">{m.text}</span>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-1.5 bg-neutral-800/90 border-t border-white/10 flex items-center gap-1.5">
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="To chat click here or press '/'..."
          maxLength={80}
          className="flex-1 bg-neutral-900 border border-white/15 rounded px-2.5 py-1 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-sky-400"
        />
        <button
          type="submit"
          className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white rounded text-xs font-semibold transition-colors flex items-center justify-center"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
