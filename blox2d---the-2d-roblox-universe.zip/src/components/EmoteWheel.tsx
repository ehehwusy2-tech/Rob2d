import React from 'react';
import { sounds } from '../audio/soundEngine';
import { Smile, X } from 'lucide-react';

interface EmoteWheelProps {
  isOpen: boolean;
  onSelectEmote: (emote: string) => void;
  onClose: () => void;
}

const EMOTES = [
  { id: 'dance', name: 'Dance 1', icon: '💃', desc: 'Classic blocky hip hop shuffle' },
  { id: 'wave', name: 'Wave', icon: '👋', desc: 'Friendly greeting' },
  { id: 'cheer', name: 'Cheer', icon: '🙌', desc: 'Jump and raise hands high' },
  { id: 'point', name: 'Point', icon: '👉', desc: 'Point at a disaster or enemy' },
  { id: 'ragdoll', name: 'Ragdoll Flop', icon: '💥', desc: 'Classic collapse into blocks' },
];

export const EmoteWheel: React.FC<EmoteWheelProps> = ({ isOpen, onSelectEmote, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-neutral-900 border border-white/15 rounded-2xl p-4 w-full max-w-xs shadow-2xl space-y-3 animate-fade-in">
        <div className="flex items-center justify-between border-b border-white/10 pb-2">
          <div className="flex items-center gap-2">
            <Smile className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">Emotes (B)</span>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {EMOTES.map((em) => (
            <button
              key={em.id}
              onClick={() => {
                sounds.playClick();
                onSelectEmote(em.id);
                onClose();
              }}
              className="p-2.5 bg-neutral-800 hover:bg-neutral-700 active:scale-95 rounded-xl border border-white/10 flex flex-col items-center justify-center gap-1 transition-all group"
            >
              <span className="text-2xl group-hover:scale-110 transition-transform">{em.icon}</span>
              <span className="text-xs font-bold text-neutral-200">{em.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
