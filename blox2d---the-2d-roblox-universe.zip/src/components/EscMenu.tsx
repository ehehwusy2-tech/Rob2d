import React, { useState } from 'react';
import { RefreshCw, Play, LogOut, Volume2, Shield } from 'lucide-react';
import { sounds } from '../audio/soundEngine';

interface EscMenuProps {
  isOpen: boolean;
  onResume: () => void;
  onResetCharacter: () => void;
  onLeaveToDiscover: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const EscMenu: React.FC<EscMenuProps> = ({
  isOpen,
  onResume,
  onResetCharacter,
  onLeaveToDiscover,
  isMuted,
  onToggleMute,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fade-in">
      <div className="bg-neutral-900 border border-white/15 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Menu Title */}
        <div className="px-5 py-3.5 bg-neutral-800/90 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Roblox Silver Square */}
            <div className="w-5 h-5 bg-white/90 rounded-xs rotate-12 flex items-center justify-center shadow-xs">
              <div className="w-2 h-2 bg-neutral-800 rounded-2xs" />
            </div>
            <span className="text-sm font-bold text-white tracking-wide">Blox2D Menu</span>
          </div>
          <span className="text-[10px] text-neutral-400 font-mono">Press Esc to close</span>
        </div>

        {/* Menu Buttons */}
        <div className="p-5 space-y-3">
          {/* Resume */}
          <button
            onClick={() => {
              sounds.playClick();
              onResume();
            }}
            className="w-full py-3 px-4 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white rounded-xl font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Resume Experience</span>
          </button>

          {/* Reset Character */}
          {confirmReset ? (
            <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl space-y-2 text-center animate-fade-in">
              <p className="text-xs text-rose-200 font-semibold">
                Are you sure you want to reset character?
              </p>
              <div className="flex items-center justify-center gap-2">
                <button
                  onClick={() => {
                    setConfirmReset(false);
                    onResetCharacter();
                  }}
                  className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition-colors"
                >
                  Reset (OOF!)
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="px-4 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-neutral-200 text-xs font-bold rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => {
                sounds.playClick();
                setConfirmReset(true);
              }}
              className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-800/80 text-rose-400 rounded-xl font-semibold text-xs border border-white/10 transition-colors flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Character</span>
            </button>
          )}

          {/* Leave Game */}
          <button
            onClick={() => {
              sounds.playClick();
              onLeaveToDiscover();
            }}
            className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-800/80 text-neutral-200 rounded-xl font-semibold text-xs border border-white/10 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Leave Experience (Discover Hub)</span>
          </button>

          {/* Audio toggle in settings */}
          <div className="pt-2 border-t border-white/10 flex items-center justify-between px-1">
            <span className="text-xs text-neutral-300 font-medium flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-neutral-400" />
              <span>Sound Effects</span>
            </span>
            <button
              onClick={onToggleMute}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                isMuted ? 'bg-neutral-800 text-neutral-400' : 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
              }`}
            >
              {isMuted ? 'Muted' : 'Enabled'}
            </button>
          </div>
        </div>

        {/* Footer info */}
        <div className="px-5 py-2.5 bg-neutral-950/80 border-t border-white/10 text-[10px] text-neutral-400 flex items-center justify-between font-mono">
          <span>Server: US-East #4402</span>
          <span>Blox2D v2.4</span>
        </div>
      </div>
    </div>
  );
};
