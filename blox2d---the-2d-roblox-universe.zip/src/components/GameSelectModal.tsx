import React from 'react';
import { GameMode } from '../types/game';
import { sounds } from '../audio/soundEngine';
import { Play, Users, ThumbsUp, Sparkles, Hammer, ShieldAlert, Award } from 'lucide-react';

interface GameSelectModalProps {
  onSelectGame: (mode: GameMode) => void;
  onOpenAvatarShop: () => void;
  robux: number;
}

interface GameCardInfo {
  id: GameMode;
  title: string;
  creator: string;
  playing: string;
  rating: string;
  description: string;
  accentColor: string;
  tag: string;
  icon: string;
}

const GAMES: GameCardInfo[] = [
  {
    id: 'disaster',
    title: 'Natural Disaster Survival 2D',
    creator: 'Stickmasterluke Tribute',
    playing: '12.4K',
    rating: '95%',
    description: 'Survive random catastrophes: Meteors, Acid Rain, Flash Floods, Tornadoes, and Volcanic Eruptions on iconic destructible maps!',
    accentColor: '#f97316',
    tag: 'Survival / Chaos',
    icon: '🌋',
  },
  {
    id: 'obby',
    title: 'Tower of Hell 2D (Obby)',
    creator: 'YXDesuno Tribute',
    playing: '18.9K',
    rating: '92%',
    description: 'Climb a towering obstacle course loaded with deadly lasers, rotating bars, disappearing steps, and bouncy jump pads before the timer expires!',
    accentColor: '#ef4444',
    tag: 'Parkour / Hardcore',
    icon: '🗼',
  },
  {
    id: 'tycoon',
    title: 'Blox Factory Tycoon 2D',
    creator: 'Zednov Tribute',
    playing: '8.7K',
    rating: '97%',
    description: 'Step on pads to purchase droppers, conveyors, cash processors, security laser gates, and construct your multi-story Roblox mansion!',
    accentColor: '#10b981',
    tag: 'Tycoon / Simulator',
    icon: '🏭',
  },
  {
    id: 'sfoth',
    title: 'Sword Fight on the Heights (SFOTH)',
    creator: 'Telamon Tribute',
    playing: '15.1K',
    rating: '96%',
    description: 'Classic 2008 sword battlegrounds suspended high in the clouds! Wield Linked Swords, Speed Coils, Gravity Coils, and Rocket Launchers!',
    accentColor: '#0ea5e9',
    tag: 'Classic PvP',
    icon: '⚔️',
  },
  {
    id: 'studio',
    title: '2D Roblox Studio Sandbox',
    creator: 'Builderman Tribute',
    playing: '4.2K',
    rating: '99%',
    description: 'Creative sandbox! Place solid bricks, red kill hazards, launch pads, conveyor belts, and test your own 2D levels in real time!',
    accentColor: '#a855f7',
    tag: 'Sandbox / Creation',
    icon: '🔨',
  },
];

export const GameSelectModal: React.FC<GameSelectModalProps> = ({
  onSelectGame,
  onOpenAvatarShop,
  robux,
}) => {
  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 select-none animate-fade-in space-y-6">
      {/* Hero Welcome Banner */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 border border-white/10 p-6 sm:p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 text-sky-400 font-mono text-xs uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Blox2D Metaverse Online</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            Discover 2D Roblox Experiences
          </h1>
          <p className="text-sm text-neutral-300 max-w-xl leading-relaxed">
            Relive the greatest classics recreated entirely in retro 2D. Pick an experience below, equip your coils and swords, or customize your blocky avatar!
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
          <button
            onClick={() => {
              sounds.playClick();
              onOpenAvatarShop();
            }}
            className="px-5 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-300 border border-amber-400/30 font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-102"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Customize Avatar</span>
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onSelectGame('disaster');
            }}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-950 transition-all hover:scale-102"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Quick Play Random</span>
          </button>
        </div>
      </div>

      {/* Experiences Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-wide flex items-center gap-2">
            <span>Popular Experiences</span>
          </h2>
          <span className="text-xs text-neutral-400">5 Playable Games Ready</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {GAMES.map((game) => (
            <div
              key={game.id}
              onClick={() => {
                sounds.playClick();
                onSelectGame(game.id);
              }}
              className="group bg-neutral-900/90 hover:bg-neutral-800/90 border border-white/10 hover:border-white/25 rounded-2xl p-4 shadow-xl cursor-pointer transition-all hover:-translate-y-1 flex flex-col justify-between"
            >
              <div>
                {/* Thumbnail Header */}
                <div
                  className="w-full h-36 rounded-xl flex items-center justify-center relative overflow-hidden shadow-inner mb-3"
                  style={{
                    background: `linear-gradient(135deg, ${game.accentColor}25, #18181b)`,
                    border: `1px solid ${game.accentColor}44`,
                  }}
                >
                  <span className="text-6xl drop-shadow-md group-hover:scale-110 transition-transform duration-300">
                    {game.icon}
                  </span>

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity backdrop-blur-2xs">
                    <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>

                  {/* Category Tag (unboxed clean label) */}
                  <div className="absolute top-2 left-2 text-[10px] font-bold text-white/90 bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                    {game.tag}
                  </div>
                </div>

                {/* Game Title & Creator */}
                <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors line-clamp-1">
                  {game.title}
                </h3>
                <p className="text-[11px] text-neutral-400 mb-2">By {game.creator}</p>

                <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed mb-4">
                  {game.description}
                </p>
              </div>

              {/* Card Footer: Active Players + Upvote + Play CTA */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 font-semibold text-neutral-300">
                    <Users className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{game.playing}</span>
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-emerald-400">
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>{game.rating}</span>
                  </span>
                </div>

                <button className="px-3 py-1 bg-emerald-600/90 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition-colors shadow-xs">
                  Play
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
