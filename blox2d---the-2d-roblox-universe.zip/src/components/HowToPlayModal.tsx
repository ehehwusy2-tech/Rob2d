import React from 'react';
import { HelpCircle, X, Shield, Swords, Zap, Crosshair } from 'lucide-react';
import { sounds } from '../audio/soundEngine';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fade-in">
      <div className="bg-neutral-900 border border-white/15 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3.5 bg-neutral-800/90 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-sky-400" />
            <h2 className="text-sm font-bold text-white tracking-wide">How to Play & Controls</h2>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto text-xs text-neutral-300">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Keyboard & Mouse Controls</span>
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">A / D or ← / →</span>
                <p className="text-neutral-400 mt-0.5">Move Left / Right</p>
              </div>
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">Space / W / ↑</span>
                <p className="text-neutral-400 mt-0.5">Jump / Climb</p>
              </div>
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">Click or Z Key</span>
                <p className="text-neutral-400 mt-0.5">Use Held Gear / Sword Slash</p>
              </div>
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">Shift or Double Tap</span>
                <p className="text-neutral-400 mt-0.5">Lunge / Sprint Dash</p>
              </div>
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">1, 2, 3, 4, 5</span>
                <p className="text-neutral-400 mt-0.5">Equip Backpack Hotbar Items</p>
              </div>
              <div className="p-2 bg-neutral-800/60 rounded-lg border border-white/5">
                <span className="font-mono font-bold text-sky-400">/ or Tab or B</span>
                <p className="text-neutral-400 mt-0.5">Chat, Leaderboard, Emotes</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Swords className="w-4 h-4 text-rose-400" />
              <span>Game Modes Guide</span>
            </h3>
            <div className="space-y-2">
              <div className="p-2.5 bg-neutral-800/50 rounded-lg border border-white/5">
                <span className="font-bold text-amber-400">🌋 Natural Disaster Survival:</span>
                <p className="text-neutral-300 mt-0.5">
                  Meteors, Flash Floods, Acid Rain, Volcanoes, and Tornadoes attack every 30 seconds! Climb to safety, find roofs, and survive the timer to earn 150 Robux!
                </p>
              </div>
              <div className="p-2.5 bg-neutral-800/50 rounded-lg border border-white/5">
                <span className="font-bold text-rose-400">🗼 Tower of Hell (Obby):</span>
                <p className="text-neutral-300 mt-0.5">
                  Navigate rotating laser beams, disappearing platforms, and jump pads to reach the Golden Vault at the top!
                </p>
              </div>
              <div className="p-2.5 bg-neutral-800/50 rounded-lg border border-white/5">
                <span className="font-bold text-emerald-400">🏭 Blox Tycoon:</span>
                <p className="text-neutral-300 mt-0.5">
                  Step on buttons to buy droppers, conveyors, cash collectors, and expand your multi-level mansion!
                </p>
              </div>
              <div className="p-2.5 bg-neutral-800/50 rounded-lg border border-white/5">
                <span className="font-bold text-sky-400">⚔️ Sword Fight on the Heights (SFOTH):</span>
                <p className="text-neutral-300 mt-0.5">
                  Classic PvP sword duels on floating sky islands! Run and slash to Lunge forward with extra knockback!
                </p>
              </div>
              <div className="p-2.5 bg-neutral-800/50 rounded-lg border border-white/5">
                <span className="font-bold text-purple-400">🔨 2D Studio Sandbox:</span>
                <p className="text-neutral-300 mt-0.5">
                  Place solids, red kill bricks, bounce pads, conveyors, and test your own obstacle course!
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-neutral-800/80 border-t border-white/10 flex justify-end">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-bold text-xs transition-colors"
          >
            Got it, Let's Play!
          </button>
        </div>
      </div>
    </div>
  );
};
