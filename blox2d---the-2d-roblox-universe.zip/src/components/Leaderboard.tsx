import React, { useState } from 'react';
import { LeaderboardEntry } from '../types/game';
import { UserPlus, Check, ShieldAlert, Award } from 'lucide-react';
import { sounds } from '../audio/soundEngine';

interface LeaderboardProps {
  isOpen: boolean;
  entries: LeaderboardEntry[];
  currentMode: string;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({
  isOpen,
  entries,
  currentMode,
}) => {
  const [friended, setFriended] = useState<Record<string, boolean>>({});
  const [reportFeedback, setReportFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFriend = (id: string) => {
    sounds.playCoin();
    setFriended((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleReport = (name: string) => {
    sounds.playClick();
    setReportFeedback(`Report submitted for ${name}: "Suspect of being too awesome" 📝`);
    setTimeout(() => setReportFeedback(null), 3000);
  };

  return (
    <div className="absolute top-12 right-3 z-30 w-72 sm:w-80 bg-neutral-900/90 backdrop-blur-md rounded-lg border border-white/10 shadow-2xl overflow-hidden pointer-events-auto">
      {/* Header */}
      <div className="px-3 py-2 bg-neutral-800/90 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-white tracking-wide">Playerlist ({entries.length})</span>
        </div>
        <span className="text-[10px] text-neutral-400">Press Tab to toggle</span>
      </div>

      {reportFeedback && (
        <div className="p-2 text-[11px] bg-sky-950/80 text-sky-300 border-b border-sky-800/40 text-center animate-fade-in">
          {reportFeedback}
        </div>
      )}

      {/* Column Titles */}
      <div className="grid grid-cols-12 px-3 py-1.5 bg-neutral-800/40 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
        <span className="col-span-6">Player</span>
        <span className="col-span-3 text-center">
          {currentMode === 'sfoth' ? 'Kills' : currentMode === 'tycoon' ? 'Cash' : 'Wins'}
        </span>
        <span className="col-span-3 text-right">Ping</span>
      </div>

      {/* Players List */}
      <div className="max-h-60 overflow-y-auto divide-y divide-white/5">
        {entries.map((player) => (
          <div
            key={player.id}
            className={`grid grid-cols-12 items-center px-3 py-2 text-xs transition-colors hover:bg-neutral-800/60 ${
              player.isLocal ? 'bg-sky-500/10' : ''
            }`}
          >
            {/* Player Info */}
            <div className="col-span-6 flex items-center gap-2 min-w-0">
              {/* Mini avatar icon */}
              <div
                className="w-5 h-5 rounded-xs shrink-0 flex items-center justify-center border border-black/30 shadow-xs"
                style={{ backgroundColor: player.avatar.skinColor }}
              >
                <div className="w-2.5 h-1 bg-black/60 rounded-xs" />
              </div>
              <span
                className={`truncate font-semibold ${
                  player.isLocal ? 'text-sky-300 font-bold' : 'text-neutral-200'
                }`}
              >
                {player.name}
              </span>
            </div>

            {/* Score / Wins / Kills */}
            <div className="col-span-3 text-center font-mono font-bold text-amber-300">
              {currentMode === 'sfoth'
                ? player.kills
                : currentMode === 'tycoon'
                ? `$${player.robux.toLocaleString()}`
                : player.wins}
            </div>

            {/* Actions + Ping */}
            <div className="col-span-3 flex items-center justify-end gap-1.5">
              {!player.isLocal && (
                <>
                  <button
                    onClick={() => handleFriend(player.id)}
                    title={friended[player.id] ? 'Friends' : 'Send Friend Request'}
                    className={`p-1 rounded transition-colors ${
                      friended[player.id]
                        ? 'text-emerald-400 bg-emerald-950/60'
                        : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                    }`}
                  >
                    {friended[player.id] ? <Check className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => handleReport(player.name)}
                    title="Report Player"
                    className="p-1 text-neutral-500 hover:text-rose-400 transition-colors"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                  </button>
                </>
              )}

              {/* Ping Indicator */}
              <div className="flex items-center gap-1 font-mono text-[10px] text-neutral-400" title={`Ping: ${player.ping}ms`}>
                <span className={`w-1.5 h-1.5 rounded-full ${player.ping < 60 ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                <span>{player.ping}ms</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
