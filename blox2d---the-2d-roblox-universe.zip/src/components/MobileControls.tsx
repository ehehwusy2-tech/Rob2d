import React from 'react';
import { ArrowLeft, ArrowRight, ArrowUp, Zap, Swords } from 'lucide-react';

interface MobileControlsProps {
  onMoveLeft: (active: boolean) => void;
  onMoveRight: (active: boolean) => void;
  onJump: () => void;
  onAction: () => void;
  onDash: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMoveLeft,
  onMoveRight,
  onJump,
  onAction,
  onDash,
}) => {
  return (
    <div className="absolute inset-x-0 bottom-16 sm:bottom-4 px-4 z-20 pointer-events-none flex items-end justify-between select-none">
      {/* Left / Right D-Pad */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <button
          onTouchStart={() => onMoveLeft(true)}
          onTouchEnd={() => onMoveLeft(false)}
          onMouseDown={() => onMoveLeft(true)}
          onMouseUp={() => onMoveLeft(false)}
          className="w-13 h-13 rounded-2xl bg-neutral-900/80 active:bg-neutral-700 backdrop-blur-sm border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <button
          onTouchStart={() => onMoveRight(true)}
          onTouchEnd={() => onMoveRight(false)}
          onMouseDown={() => onMoveRight(true)}
          onMouseUp={() => onMoveRight(false)}
          className="w-13 h-13 rounded-2xl bg-neutral-900/80 active:bg-neutral-700 backdrop-blur-sm border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
        >
          <ArrowRight className="w-6 h-6" />
        </button>
      </div>

      {/* Action Buttons: Jump, Attack, Dash */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <button
          onClick={onDash}
          className="w-11 h-11 rounded-2xl bg-amber-600/80 active:bg-amber-500 backdrop-blur-sm border border-amber-400/40 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Sprint / Lunge"
        >
          <Zap className="w-5 h-5" />
        </button>

        <button
          onClick={onAction}
          className="w-13 h-13 rounded-2xl bg-rose-600/85 active:bg-rose-500 backdrop-blur-sm border border-rose-400/40 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Slash / Attack"
        >
          <Swords className="w-6 h-6" />
        </button>

        <button
          onClick={onJump}
          className="w-14 h-14 rounded-2xl bg-sky-600/85 active:bg-sky-500 backdrop-blur-sm border border-sky-400/40 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Jump"
        >
          <ArrowUp className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
};
