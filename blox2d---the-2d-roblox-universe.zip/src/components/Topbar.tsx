import React from 'react';
import { 
  MessageSquare, 
  Menu, 
  Volume2, 
  VolumeX, 
  Users, 
  Smile, 
  Backpack, 
  Sparkles,
  Compass,
  PlusCircle,
  HelpCircle
} from 'lucide-react';
import { GameMode } from '../types/game';
import { sounds } from '../audio/soundEngine';

interface TopbarProps {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  onToggleEscMenu: () => void;
  onToggleChat: () => void;
  isChatOpen: boolean;
  onToggleLeaderboard: () => void;
  isLeaderboardOpen: boolean;
  onToggleEmotes: () => void;
  isEmotesOpen: boolean;
  onToggleBackpack: () => void;
  isBackpackOpen: boolean;
  robux: number;
  onClaimDailyRobux: () => void;
  canClaimDaily: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenAvatarShop: () => void;
  onOpenHowToPlay: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  currentMode,
  onSelectMode,
  onToggleEscMenu,
  onToggleChat,
  isChatOpen,
  onToggleLeaderboard,
  isLeaderboardOpen,
  onToggleEmotes,
  isEmotesOpen,
  onToggleBackpack,
  isBackpackOpen,
  robux,
  onClaimDailyRobux,
  canClaimDaily,
  isMuted,
  onToggleMute,
  onOpenAvatarShop,
  onOpenHowToPlay
}) => {
  const getModeTitle = () => {
    switch (currentMode) {
      case 'disaster':
        return '🌋 Natural Disaster Survival 2D';
      case 'obby':
        return '🗼 Tower of Hell 2D (Obby)';
      case 'tycoon':
        return '🏭 Blox Tycoon 2D';
      case 'sfoth':
        return '⚔️ Sword Fight on the Heights 2D';
      case 'studio':
        return '🔨 2D Roblox Studio Sandbox';
      case 'avatar_shop':
        return '🛍️ Avatar Shop / Catalog';
      default:
        return 'Blox2D Universe';
    }
  };

  return (
    <header className="relative z-40 flex items-center justify-between px-3 py-1.5 bg-[#18181b]/95 backdrop-blur border-b border-white/10 text-white select-none shadow-md">
      {/* Left controls: Roblox Silver Logo Menu + Chat + Backpack + Emotes */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Iconic Roblox Silver/Dark Logo / Esc Menu button */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleEscMenu();
          }}
          title="Roblox Menu (Esc)"
          aria-label="Roblox Menu"
          className="flex items-center justify-center w-8 h-8 rounded bg-gradient-to-b from-neutral-700 to-neutral-800 hover:from-neutral-600 hover:to-neutral-700 active:scale-95 border border-white/20 shadow-inner group transition-transform"
        >
          {/* Classic tilted square logo icon */}
          <div className="w-4 h-4 bg-white/90 group-hover:bg-white rounded-xs rotate-12 flex items-center justify-center shadow-xs">
            <div className="w-1.5 h-1.5 bg-neutral-800 rounded-2xs" />
          </div>
        </button>

        {/* Chat Toggle */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleChat();
          }}
          title="Toggle Chat (/)"
          aria-label="Toggle Chat"
          className={`flex items-center justify-center w-8 h-8 rounded border transition-colors ${
            isChatOpen 
              ? 'bg-neutral-700 border-white/30 text-sky-400' 
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
        </button>

        {/* Backpack Toggle */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleBackpack();
          }}
          title="Toggle Backpack Hotbar (`)`"
          aria-label="Toggle Backpack"
          className={`flex items-center justify-center w-8 h-8 rounded border transition-colors ${
            isBackpackOpen 
              ? 'bg-neutral-700 border-white/30 text-amber-400' 
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <Backpack className="w-4 h-4" />
        </button>

        {/* Emotes Wheel */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleEmotes();
          }}
          title="Emotes (B)"
          aria-label="Emotes"
          className={`flex items-center justify-center w-8 h-8 rounded border transition-colors ${
            isEmotesOpen 
              ? 'bg-neutral-700 border-white/30 text-yellow-400' 
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <Smile className="w-4 h-4" />
        </button>

        {/* Discover / Games Hub Button */}
        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('discover');
          }}
          title="Discover More Experiences"
          className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded border transition-colors ${
            currentMode === 'discover'
              ? 'bg-neutral-700 border-white/40 text-white'
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <Compass className="w-3.5 h-3.5 text-rose-400" />
          <span>Discover</span>
        </button>

        {/* Avatar Shop Catalog Button */}
        <button
          onClick={() => {
            sounds.playClick();
            onOpenAvatarShop();
          }}
          title="Avatar Shop & Catalog"
          className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded border transition-colors ${
            currentMode === 'avatar_shop'
              ? 'bg-neutral-700 border-white/40 text-amber-300'
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Avatar Shop</span>
        </button>
      </div>

      {/* Center Game Title (Quiet, no pill) */}
      <div className="flex items-center gap-2">
        <span className="text-xs sm:text-sm font-bold tracking-wide text-neutral-200 drop-shadow-xs">
          {getModeTitle()}
        </span>
      </div>

      {/* Right controls: Robux + Leaderboard + Audio + How-to */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Robux Balance Chip */}
        <div 
          onClick={() => {
            sounds.playClick();
            onOpenAvatarShop();
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-emerald-500/40 cursor-pointer hover:border-emerald-400 transition-colors shadow-inner"
          title="Robux Balance (Click to open Shop)"
        >
          {/* Classic green/gold Hexagon Robux icon */}
          <div className="w-3.5 h-3.5 bg-emerald-500 rounded-xs rotate-45 flex items-center justify-center">
            <span className="text-[9px] font-black text-neutral-900 -rotate-45 leading-none">R$</span>
          </div>
          <span className="text-xs font-bold text-emerald-400 tracking-tight">
            {robux.toLocaleString()}
          </span>
          {canClaimDaily && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClaimDailyRobux();
              }}
              className="ml-1 text-[10px] font-bold text-amber-300 hover:text-amber-200 flex items-center gap-0.5 underline decoration-dotted"
              title="Claim +150 Free Robux!"
            >
              <PlusCircle className="w-3 h-3 text-amber-400 animate-pulse" />
              <span>Free</span>
            </button>
          )}
        </div>

        {/* How to play / Controls */}
        <button
          onClick={() => {
            sounds.playClick();
            onOpenHowToPlay();
          }}
          title="Controls & Instructions"
          aria-label="Controls"
          className="flex items-center justify-center w-8 h-8 rounded bg-neutral-800/80 border border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Leaderboard Toggle (Tab) */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleLeaderboard();
          }}
          title="Player List / Leaderboard (Tab)"
          aria-label="Leaderboard"
          className={`flex items-center justify-center w-8 h-8 rounded border transition-colors ${
            isLeaderboardOpen 
              ? 'bg-neutral-700 border-white/30 text-emerald-400' 
              : 'bg-neutral-800/80 border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
        >
          <Users className="w-4 h-4" />
        </button>

        {/* Sound Mute */}
        <button
          onClick={onToggleMute}
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          aria-label="Toggle Sound"
          className="flex items-center justify-center w-8 h-8 rounded bg-neutral-800/80 border border-white/10 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-neutral-300" />}
        </button>
      </div>
    </header>
  );
};
