import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  GameMode, 
  Player, 
  AvatarConfig, 
  GearItem, 
  StudioBrick, 
  Badge 
} from '../types/game';
import { drawAvatar } from '../utils/avatarDrawer';
import { sounds } from '../audio/soundEngine';
import confetti from 'canvas-confetti';
import { BOT_NAMES, CHAT_PHRASES } from '../data/robloxData';

interface GameCanvasProps {
  mode: GameMode;
  avatar: AvatarConfig;
  equippedGear: GearItem | null;
  onSelectGear: (gear: GearItem | null) => void;
  robux: number;
  onAddRobux: (amount: number) => void;
  onUnlockBadge: (badgeId: string) => void;
  onAddKill: () => void;
  onAddWin: () => void;
  onNewChatMessage: (sender: string, text: string, color?: string) => void;
  localPlayerEmote: string | null;
  onClearEmote: () => void;
  mobileLeft: boolean;
  mobileRight: boolean;
}

interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  type: 'solid' | 'kill' | 'bounce' | 'conveyor' | 'checkpoint' | 'destructible';
  speed?: number;
  hp?: number;
  alpha?: number;
  label?: string;
}

interface DisasterEvent {
  name: string;
  type: 'meteors' | 'flood' | 'acid_rain' | 'tornado' | 'volcano';
  description: string;
  timer: number;
}

interface TycoonButton {
  id: string;
  title: string;
  cost: number;
  x: number;
  y: number;
  w: number;
  h: number;
  purchased: boolean;
  color: string;
}

interface TycoonOre {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  value: number;
  color: string;
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'rocket' | 'meteor' | 'acid' | 'lava';
  ownerId?: string;
  radius: number;
  color: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  mode,
  avatar,
  equippedGear,
  onSelectGear,
  robux,
  onAddRobux,
  onUnlockBadge,
  onAddKill,
  onAddWin,
  onNewChatMessage,
  localPlayerEmote,
  onClearEmote,
  mobileLeft,
  mobileRight,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Studio Edit state
  const [studioTool, setStudioTool] = useState<'solid' | 'kill' | 'bounce' | 'conveyor' | 'coin' | 'erase'>('solid');
  const [studioColor, setStudioColor] = useState<string>('#64748b');
  const [isTestingStudio, setIsTestingStudio] = useState<boolean>(false);
  const [customBricks, setCustomBricks] = useState<StudioBrick[]>([]);

  // Announcements banner
  const [announcement, setAnnouncement] = useState<string | null>(null);

  // Disaster game state
  const disasterRef = useRef<{
    active: DisasterEvent | null;
    phase: 'intermission' | 'active';
    phaseTimer: number;
    waterLevel: number;
    tornadoX: number;
    tornadoDir: number;
  }>({
    active: null,
    phase: 'intermission',
    phaseTimer: 8,
    waterLevel: 600,
    tornadoX: 400,
    tornadoDir: 1,
  });

  // Obby checkpoint & timer
  const obbyCheckpointRef = useRef<{ x: number; y: number }>({ x: 80, y: 520 });

  // Tycoon internal state
  const tycoonStateRef = useRef<{
    cash: number;
    multiplier: number;
    droppers: { id: string; x: number; y: number; interval: number; lastDrop: number; value: number; color: string }[];
    ores: TycoonOre[];
    buttons: TycoonButton[];
  }>({
    cash: 0,
    multiplier: 1,
    droppers: [],
    ores: [],
    buttons: [
      { id: 'dropper1', title: '[FREE] Dropper 1', cost: 0, x: 120, y: 520, w: 90, h: 20, purchased: false, color: '#22c55e' },
      { id: 'walls', title: '[$40] Buy Walls', cost: 40, x: 230, y: 520, w: 90, h: 20, purchased: false, color: '#3b82f6' },
      { id: 'dropper2', title: '[$100] Silver Dropper', cost: 100, x: 340, y: 520, w: 100, h: 20, purchased: false, color: '#94a3b8' },
      { id: 'upgrader', title: '[$250] 2x Ore Upgrader', cost: 250, x: 460, y: 520, w: 110, h: 20, purchased: false, color: '#a855f7' },
      { id: 'floor2', title: '[$500] 2nd Floor & Stair', cost: 500, x: 590, y: 520, w: 120, h: 20, purchased: false, color: '#eab308' },
      { id: 'dropper3', title: '[$1000] Golden Dropper', cost: 1000, x: 300, y: 350, w: 110, h: 20, purchased: false, color: '#f59e0b' },
      { id: 'laser_gate', title: '[$2000] Laser Security', cost: 2000, x: 440, y: 350, w: 110, h: 20, purchased: false, color: '#ef4444' },
      { id: 'mega_dropper', title: '[$4000] Rainbow Mega Dropper', cost: 4000, x: 580, y: 350, w: 140, h: 20, purchased: false, color: '#ec4899' },
    ],
  });

  // Projectiles & Particles
  const projectilesRef = useRef<Projectile[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const screenShakeRef = useRef<number>(0);

  // Key states
  const keysRef = useRef<Record<string, boolean>>({});

  // Players (Local + Bots)
  const playersRef = useRef<Player[]>([]);

  // Setup initial players
  useEffect(() => {
    const local: Player = {
      id: 'local',
      name: 'You',
      isLocal: true,
      x: 100,
      y: 400,
      vx: 0,
      vy: 0,
      width: 20,
      height: 44,
      grounded: false,
      hp: 100,
      maxHp: 100,
      avatar,
      equippedGear,
      facing: 'right',
      currentEmote: null,
      emoteTimer: 0,
      chatBubble: null,
      chatTimer: 0,
      kills: 0,
      isAlive: true,
      invincibleTimer: 60,
      lungeTimer: 0,
      walkFrame: 0,
    };

    // Bots with varied funny avatars
    const botColors = [
      { skin: '#fde047', torso: '#0284c7', leg: '#16a34a', hat: 'none', face: 'smile', acc: 'none' },
      { skin: '#fde047', torso: '#dc2626', leg: '#18181b', hat: 'visor', face: 'winning', acc: 'cape' },
      { skin: '#fed7aa', torso: '#18181b', leg: '#64748b', hat: 'bacon', face: 'chill', acc: 'none' },
      { skin: '#fde047', torso: '#fbbf24', leg: '#1e1b4b', hat: 'valkyrie', face: 'epic', acc: 'wings' },
      { skin: '#fde047', torso: '#1e1b4b', leg: '#18181b', hat: 'dominus', face: 'evil', acc: 'none' },
    ];

    const bots: Player[] = BOT_NAMES.slice(0, 4).map((name, idx) => {
      const c = botColors[idx % botColors.length];
      return {
        id: `bot_${idx}`,
        name,
        isLocal: false,
        x: 200 + idx * 140,
        y: 400,
        vx: 0,
        vy: 0,
        width: 20,
        height: 44,
        grounded: false,
        hp: 100,
        maxHp: 100,
        avatar: {
          skinColor: c.skin,
          torsoColor: c.torso,
          leftLegColor: c.leg,
          rightLegColor: c.leg,
          hat: c.hat,
          face: c.face,
          accessory: c.acc,
          animStyle: 'classic',
        },
        equippedGear: {
          id: 'sword',
          name: 'Linked Sword',
          icon: '⚔️',
          slot: 1,
          type: 'sword',
          cooldown: 400,
          lastUsed: 0,
        },
        facing: idx % 2 === 0 ? 'right' : 'left',
        currentEmote: null,
        emoteTimer: 0,
        chatBubble: null,
        chatTimer: 0,
        kills: Math.floor(Math.random() * 3),
        isAlive: true,
        invincibleTimer: 0,
        lungeTimer: 0,
        walkFrame: 0,
      };
    });

    playersRef.current = [local, ...bots];
  }, []);

  // Update avatar and equipped gear when changed in UI
  useEffect(() => {
    const local = playersRef.current.find((p) => p.isLocal);
    if (local) {
      local.avatar = avatar;
      local.equippedGear = equippedGear;
    }
  }, [avatar, equippedGear]);

  // Update local player emote when triggered
  useEffect(() => {
    if (localPlayerEmote) {
      const local = playersRef.current.find((p) => p.isLocal);
      if (local && local.isAlive) {
        if (localPlayerEmote === 'ragdoll') {
          local.hp = 0;
          local.isAlive = false;
          sounds.playOof();
        } else {
          local.currentEmote = localPlayerEmote;
          local.emoteTimer = 180; // 3 seconds
        }
      }
      onClearEmote();
    }
  }, [localPlayerEmote, onClearEmote]);

  // Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT') return;
      keysRef.current[e.code] = true;
      keysRef.current[e.key.toLowerCase()] = true;

      // Quick Action / Sword attack
      if (e.code === 'KeyZ' || e.code === 'KeyX' || e.code === 'KeyF') {
        triggerAction();
      }
      // Jump
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        triggerJump();
      }
      // Shift / Dash
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        triggerDash();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
      keysRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Action / Attack Trigger
  const triggerAction = useCallback(() => {
    const local = playersRef.current.find((p) => p.isLocal);
    if (!local || !local.isAlive) return;

    if (!local.equippedGear || local.equippedGear.type === 'sword') {
      // Sword Slash
      sounds.playSwordSlash();
      local.lungeTimer = 18;
      // Hit check nearby players/bots
      const attackRange = 55;
      playersRef.current.forEach((target) => {
        if (target.id === local.id || !target.isAlive || target.invincibleTimer > 0) return;
        const dx = target.x - local.x;
        const dy = Math.abs(target.y - local.y);
        const inFront = (local.facing === 'right' && dx > 0 && dx < attackRange) ||
                        (local.facing === 'left' && dx < 0 && dx > -attackRange);

        if (inFront && dy < 35) {
          sounds.playSwordHit();
          const dmg = local.lungeTimer > 0 ? 55 : 35;
          target.hp -= dmg;
          target.vx = (local.facing === 'right' ? 8 : -8);
          target.vy = -4;

          // Spawn blood/spark particles
          spawnParticles(target.x + 10, target.y + 20, '#ef4444', 8);

          if (target.hp <= 0) {
            target.hp = 0;
            target.isAlive = false;
            sounds.playOof();
            local.kills += 1;
            onAddKill();
            onAddRobux(25);
            onUnlockBadge('sword_master');
            onNewChatMessage('SYSTEM', `You eliminated ${target.name}! (+25 Robux)`, '#38bdf8');
          }
        }
      });
    } else if (local.equippedGear.type === 'cola') {
      // Bloxy Cola Chug
      sounds.playCola();
      local.hp = Math.min(local.maxHp, local.hp + 40);
      local.vx = (local.facing === 'right' ? 7 : -7);
      spawnParticles(local.x + 10, local.y, '#f59e0b', 10);
      onNewChatMessage('You', '*slurps delicious Bloxy Cola*', '#ef4444');
    } else if (local.equippedGear.type === 'rocket') {
      // Launch Rocket
      sounds.playExplosion();
      projectilesRef.current.push({
        x: local.x + (local.facing === 'right' ? 24 : -10),
        y: local.y + 12,
        vx: local.facing === 'right' ? 11 : -11,
        vy: -0.5,
        type: 'rocket',
        ownerId: local.id,
        radius: 6,
        color: '#ea580c',
      });
    }
  }, [onAddKill, onAddRobux, onUnlockBadge, onNewChatMessage]);

  // Jump Trigger
  const triggerJump = useCallback(() => {
    const local = playersRef.current.find((p) => p.isLocal);
    if (!local || !local.isAlive) return;

    if (local.grounded) {
      sounds.playJump();
      const jumpVel = local.equippedGear?.type === 'gravity_coil' ? -14.5 : -11.5;
      local.vy = jumpVel;
      local.grounded = false;
      if (local.equippedGear?.type === 'gravity_coil') {
        sounds.playCoil();
      }
    }
  }, []);

  // Dash / Lunge Trigger
  const triggerDash = useCallback(() => {
    const local = playersRef.current.find((p) => p.isLocal);
    if (!local || !local.isAlive) return;
    local.vx = local.facing === 'right' ? 10 : -10;
    local.lungeTimer = 16;
    if (local.equippedGear?.type === 'speed_coil') {
      sounds.playCoil();
    }
  }, []);

  const spawnParticles = (x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6,
        color,
        size: Math.random() * 4 + 2,
        life: 0,
        maxLife: Math.random() * 20 + 15,
      });
    }
  };

  // Get Map Platforms for each mode
  const getPlatforms = useCallback((): Platform[] => {
    if (mode === 'studio') {
      // Custom Studio Bricks
      return customBricks.map((b) => ({
        x: b.x,
        y: b.y,
        w: b.w,
        h: b.h,
        color: b.color,
        type: b.type === 'coin' ? 'checkpoint' : b.type,
      }));
    }

    if (mode === 'disaster') {
      // Happy Home in Robloxia + Towers
      return [
        // Main Ground
        { x: 0, y: 560, w: 900, h: 40, color: '#15803d', type: 'solid' },
        // Two-story house foundation & floors
        { x: 260, y: 480, w: 220, h: 16, color: '#78350f', type: 'solid' }, // 1st floor ceiling
        { x: 280, y: 400, w: 180, h: 16, color: '#78350f', type: 'solid' }, // 2nd floor ceiling
        { x: 310, y: 320, w: 120, h: 16, color: '#b91c1c', type: 'solid' }, // Pitched roof
        // Chimney
        { x: 390, y: 270, w: 28, h: 50, color: '#991b1b', type: 'solid' },
        // House walls (destructible)
        { x: 260, y: 480, w: 14, h: 80, color: '#d97706', type: 'solid' },
        { x: 466, y: 480, w: 14, h: 80, color: '#d97706', type: 'solid' },
        // Rocket Launch Tower on left
        { x: 60, y: 500, w: 110, h: 14, color: '#475569', type: 'solid' },
        { x: 80, y: 420, w: 90, h: 14, color: '#475569', type: 'solid' },
        { x: 90, y: 340, w: 80, h: 14, color: '#475569', type: 'solid' },
        { x: 100, y: 240, w: 60, h: 14, color: '#38bdf8', type: 'bounce' }, // Top jump pad
        // High Sky crane on right
        { x: 620, y: 460, w: 140, h: 14, color: '#d97706', type: 'solid' },
        { x: 660, y: 360, w: 120, h: 14, color: '#d97706', type: 'solid' },
        { x: 700, y: 260, w: 100, h: 14, color: '#d97706', type: 'solid' },
      ];
    }

    if (mode === 'obby') {
      // Tower of Hell sections (stacked vertically with checkpoints)
      return [
        // Ground stage
        { x: 0, y: 560, w: 900, h: 40, color: '#1e293b', type: 'solid' },
        // Stage 1: Cyan steps
        { x: 80, y: 510, w: 70, h: 14, color: '#06b6d4', type: 'solid' },
        { x: 200, y: 470, w: 60, h: 14, color: '#06b6d4', type: 'solid' },
        { x: 310, y: 430, w: 60, h: 14, color: '#06b6d4', type: 'solid' },
        // Red Kill Laser on floor
        { x: 160, y: 554, w: 130, h: 6, color: '#ef4444', type: 'kill' },
        { x: 390, y: 554, w: 140, h: 6, color: '#ef4444', type: 'kill' },
        // Stage 2: Magenta laser crossing
        { x: 420, y: 390, w: 80, h: 14, color: '#d946ef', type: 'solid' },
        { x: 550, y: 350, w: 30, h: 14, color: '#ef4444', type: 'kill' }, // Trap block
        { x: 630, y: 340, w: 70, h: 14, color: '#d946ef', type: 'solid' },
        // Bouncy Trampoline Pad
        { x: 740, y: 320, w: 50, h: 14, color: '#eab308', type: 'bounce' },
        // Stage 3: High Sky Conveyor & Lasers
        { x: 600, y: 210, w: 130, h: 14, color: '#3b82f6', type: 'conveyor', speed: -2 },
        { x: 440, y: 200, w: 50, h: 14, color: '#22c55e', type: 'solid' },
        { x: 330, y: 170, w: 40, h: 14, color: '#ef4444', type: 'kill' },
        { x: 230, y: 160, w: 60, h: 14, color: '#22c55e', type: 'solid' },
        // Golden Top Vault Stage!
        { x: 80, y: 120, w: 100, h: 18, color: '#fbbf24', type: 'checkpoint', label: 'VAULT' },
      ];
    }

    if (mode === 'tycoon') {
      // Blox Tycoon plot
      return [
        // Ground plot
        { x: 0, y: 560, w: 900, h: 40, color: '#334155', type: 'solid' },
        // Main Conveyor Belt
        { x: 100, y: 460, w: 500, h: 14, color: '#0284c7', type: 'conveyor', speed: 2.2 },
        // Cash Collector furnace on right
        { x: 600, y: 430, w: 70, h: 44, color: '#15803d', type: 'solid', label: 'FURNACE' },
        // 2nd Floor (conditional if purchased)
        ...(tycoonStateRef.current.buttons.find((b) => b.id === 'floor2')?.purchased
          ? [
              { x: 200, y: 380, w: 500, h: 14, color: '#e2e8f0', type: 'solid' as const },
              { x: 150, y: 480, w: 40, h: 14, color: '#eab308', type: 'bounce' as const }, // Elevator jump pad
            ]
          : []),
        // Walls (conditional if purchased)
        ...(tycoonStateRef.current.buttons.find((b) => b.id === 'walls')?.purchased
          ? [
              { x: 80, y: 380, w: 16, h: 180, color: '#475569', type: 'solid' as const },
              { x: 740, y: 380, w: 16, h: 180, color: '#475569', type: 'solid' as const },
            ]
          : []),
      ];
    }

    if (mode === 'sfoth') {
      // Classic Floating Sky Islands over void
      return [
        // Central Temple Island
        { x: 300, y: 440, w: 300, h: 22, color: '#64748b', type: 'solid' },
        { x: 380, y: 360, w: 140, h: 16, color: '#94a3b8', type: 'solid' },
        // Left Floating Pillar
        { x: 100, y: 480, w: 120, h: 18, color: '#64748b', type: 'solid' },
        { x: 40, y: 390, w: 60, h: 16, color: '#0284c7', type: 'bounce' }, // Speed coil tower pad
        // Right Floating Pillar
        { x: 680, y: 480, w: 120, h: 18, color: '#64748b', type: 'solid' },
        { x: 800, y: 390, w: 60, h: 16, color: '#a855f7', type: 'bounce' }, // Gravity coil tower pad
        // Sky Bridge
        { x: 230, y: 460, w: 60, h: 10, color: '#cbd5e1', type: 'solid' },
        { x: 610, y: 460, w: 60, h: 10, color: '#cbd5e1', type: 'solid' },
        // High Arch
        { x: 410, y: 260, w: 80, h: 14, color: '#fbbf24', type: 'solid' },
      ];
    }

    return [{ x: 0, y: 560, w: 900, h: 40, color: '#334155', type: 'solid' }];
  }, [mode, customBricks]);

  // Main Game Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;
    let botChatTimer = 0;

    const DISASTERS: DisasterEvent[] = [
      { name: 'Meteor Shower', type: 'meteors', description: 'Blazing meteors rain from the sky! Avoid direct hits!', timer: 32 },
      { name: 'Flash Flood', type: 'flood', description: 'Radioactive toxic flood is rising! Climb to the highest rooftop!', timer: 32 },
      { name: 'Acid Rain', type: 'acid_rain', description: 'Corrosive rain burns exposed players! Seek shelter under roofs!', timer: 32 },
      { name: 'Tornado', type: 'tornado', description: 'Swirling twister ripping through Robloxia! Stay clear!', timer: 32 },
      { name: 'Volcano Eruption', type: 'volcano', description: 'Lava rocks launching from the caldera!', timer: 32 },
    ];

    const gameLoop = () => {
      time += 0.016;
      const width = canvas.width;
      const height = canvas.height;

      // Handle screen shake
      if (screenShakeRef.current > 0) {
        screenShakeRef.current -= 0.5;
      }
      const shakeX = screenShakeRef.current > 0 ? (Math.random() - 0.5) * screenShakeRef.current : 0;
      const shakeY = screenShakeRef.current > 0 ? (Math.random() - 0.5) * screenShakeRef.current : 0;

      ctx.save();
      ctx.translate(shakeX, shakeY);

      // Background Sky rendering based on mode & disaster
      drawSky(ctx, width, height, mode, disasterRef.current.active);

      const platforms = getPlatforms();

      // ==========================================
      // DISASTER LOGIC & GENERATION
      // ==========================================
      if (mode === 'disaster') {
        const d = disasterRef.current;
        d.phaseTimer -= 0.016;

        if (d.phase === 'intermission') {
          if (d.phaseTimer <= 0) {
            // Start disaster
            const chosen = DISASTERS[Math.floor(Math.random() * DISASTERS.length)];
            d.active = chosen;
            d.phase = 'active';
            d.phaseTimer = chosen.timer;
            d.waterLevel = 600;
            sounds.playDisasterSiren();
            setAnnouncement(`[DISASTER]: ${chosen.name}! ${chosen.description}`);
            onNewChatMessage('SYSTEM', `Disaster: ${chosen.name}!`, '#ef4444');
          }
        } else if (d.phase === 'active' && d.active) {
          // Ongoing disaster effects
          if (d.active.type === 'meteors' && Math.random() < 0.12) {
            projectilesRef.current.push({
              x: Math.random() * width,
              y: -20,
              vx: (Math.random() - 0.5) * 4,
              vy: Math.random() * 5 + 6,
              type: 'meteor',
              radius: Math.random() * 8 + 8,
              color: '#f97316',
            });
          } else if (d.active.type === 'flood') {
            d.waterLevel = Math.max(300, d.waterLevel - 0.22);
          } else if (d.active.type === 'tornado') {
            d.tornadoX += d.tornadoDir * 2.2;
            if (d.tornadoX > width - 100) d.tornadoDir = -1;
            if (d.tornadoX < 100) d.tornadoDir = 1;
            screenShakeRef.current = 1.5;
          } else if (d.active.type === 'volcano' && Math.random() < 0.1) {
            projectilesRef.current.push({
              x: 450 + (Math.random() - 0.5) * 100,
              y: 540,
              vx: (Math.random() - 0.5) * 10,
              vy: -(Math.random() * 8 + 12),
              type: 'lava',
              radius: Math.random() * 7 + 6,
              color: '#dc2626',
            });
            screenShakeRef.current = 2;
          }

          if (d.phaseTimer <= 0) {
            // Disaster Survived!
            d.phase = 'intermission';
            d.phaseTimer = 8;
            d.active = null;
            d.waterLevel = 600;

            const local = playersRef.current.find((p) => p.isLocal);
            if (local && local.isAlive) {
              sounds.playWinFanfare();
              confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
              onAddRobux(150);
              onAddWin();
              onUnlockBadge('survivor');
              setAnnouncement('🎉 YOU SURVIVED THE DISASTER! Awarded +150 Robux!');
              onNewChatMessage('SYSTEM', 'You survived the round! +150 Robux awarded.', '#22c55e');
            } else {
              setAnnouncement('Round ended! Better luck surviving next time!');
            }
          }
        }
      }

      // ==========================================
      // TYCOON FACTORY LOGIC
      // ==========================================
      if (mode === 'tycoon') {
        const t = tycoonStateRef.current;
        // Droppers spawn ores
        t.droppers.forEach((drop) => {
          if (time - drop.lastDrop > drop.interval) {
            drop.lastDrop = time;
            t.ores.push({
              id: Math.random(),
              x: drop.x,
              y: drop.y,
              vx: 0,
              vy: 0,
              value: drop.value * t.multiplier,
              color: drop.color,
            });
          }
        });

        // Update Ores physics & conveyor collection
        t.ores.forEach((ore) => {
          ore.vy += 0.4;
          ore.y += ore.vy;
          ore.x += ore.vx;

          // Conveyor belt at y: 460
          if (ore.y >= 452 && ore.y <= 468 && ore.x >= 100 && ore.x <= 600) {
            ore.y = 452;
            ore.vy = 0;
            ore.vx = 2.2;
          }

          // Furnace Collection check
          if (ore.x >= 600 && ore.y >= 420) {
            ore.value = 0; // Collected
            t.cash += ore.value || 10;
            sounds.playCoin();
            spawnParticles(ore.x + 8, ore.y + 4, '#eab308', 4);
          }
        });

        // Remove collected ores
        t.ores = t.ores.filter((ore) => ore.value > 0 && ore.y < 580);
      }

      // Draw Platforms
      platforms.forEach((p) => {
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.w, p.h);

        // Brick stud texture (classic Roblox circles on top)
        ctx.fillStyle = '#ffffff25';
        for (let sx = p.x + 6; sx < p.x + p.w - 4; sx += 14) {
          ctx.beginPath();
          ctx.arc(sx, p.y + 2, 2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Platform border
        ctx.strokeStyle = '#00000033';
        ctx.lineWidth = 1;
        ctx.strokeRect(p.x, p.y, p.w, p.h);

        // Neon Glow for Kill Hazards
        if (p.type === 'kill') {
          ctx.shadowColor = '#ef4444';
          ctx.shadowBlur = 8;
          ctx.fillStyle = '#f87171';
          ctx.fillRect(p.x, p.y, p.w, 2);
          ctx.shadowBlur = 0;
        }

        // Conveyor moving arrows
        if (p.type === 'conveyor') {
          ctx.fillStyle = '#ffffff99';
          const offset = (time * 40 * (p.speed || 1)) % 16;
          for (let ax = p.x + offset; ax < p.x + p.w - 6; ax += 16) {
            ctx.beginPath();
            ctx.moveTo(ax, p.y + 4);
            ctx.lineTo(ax + 5, p.y + 7);
            ctx.lineTo(ax, p.y + 10);
            ctx.stroke();
          }
        }

        // Vault Label
        if (p.label) {
          ctx.font = 'bold 10px Inter, sans-serif';
          ctx.fillStyle = '#ffffff';
          ctx.textAlign = 'center';
          ctx.fillText(p.label, p.x + p.w / 2, p.y - 4);
        }
      });

      // Draw Tycoon Buttons on floor
      if (mode === 'tycoon') {
        const t = tycoonStateRef.current;
        t.buttons.forEach((btn) => {
          if (btn.purchased) return;
          ctx.fillStyle = btn.color;
          ctx.fillRect(btn.x, btn.y, btn.w, btn.h);
          ctx.strokeStyle = '#ffffff88';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(btn.x, btn.y, btn.w, btn.h);

          // Button title & cost text
          ctx.font = 'bold 9px Inter, sans-serif';
          ctx.fillStyle = '#ffffff';
          ctx.textAlign = 'center';
          ctx.fillText(btn.title, btn.x + btn.w / 2, btn.y + btn.h / 2 + 3);
        });

        // Draw Tycoon Ores
        t.ores.forEach((ore) => {
          ctx.fillStyle = ore.color;
          ctx.fillRect(ore.x, ore.y, 10, 10);
          ctx.strokeStyle = '#00000044';
          ctx.strokeRect(ore.x, ore.y, 10, 10);
        });

        // Draw Tycoon Droppers
        t.droppers.forEach((drop) => {
          ctx.fillStyle = '#475569';
          ctx.fillRect(drop.x - 4, drop.y - 20, 24, 20);
          ctx.fillStyle = drop.color;
          ctx.fillRect(drop.x, drop.y - 6, 16, 6);
        });
      }

      // Draw Disaster Flood Water if active
      if (mode === 'disaster' && disasterRef.current.active?.type === 'flood') {
        ctx.fillStyle = '#059669aa';
        ctx.fillRect(0, disasterRef.current.waterLevel, width, height - disasterRef.current.waterLevel);
        // Water surface line
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let x = 0; x < width; x += 10) {
          const y = disasterRef.current.waterLevel + Math.sin(time * 6 + x * 0.05) * 3;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // Draw Disaster Tornado if active
      if (mode === 'disaster' && disasterRef.current.active?.type === 'tornado') {
        const tx = disasterRef.current.tornadoX;
        ctx.save();
        ctx.fillStyle = '#94a3b866';
        ctx.beginPath();
        ctx.moveTo(tx - 6, 560);
        ctx.lineTo(tx + 6, 560);
        ctx.lineTo(tx + 40, 180);
        ctx.lineTo(tx - 40, 180);
        ctx.closePath();
        ctx.fill();

        // Swirling debris
        ctx.fillStyle = '#64748b';
        for (let i = 0; i < 8; i++) {
          const dy = 560 - i * 45;
          const wobble = Math.sin(time * 12 + i) * (15 + i * 4);
          ctx.fillRect(tx + wobble, dy, 6, 6);
        }
        ctx.restore();
      }

      // Draw Acid Rain Droplets if active
      if (mode === 'disaster' && disasterRef.current.active?.type === 'acid_rain') {
        ctx.strokeStyle = '#84cc16cc';
        ctx.lineWidth = 1.5;
        for (let i = 0; i < 25; i++) {
          const rx = (Math.sin(i * 99 + time * 3) * 0.5 + 0.5) * width;
          const ry = ((i * 37 + time * 600) % height);
          ctx.beginPath();
          ctx.moveTo(rx, ry);
          ctx.lineTo(rx - 2, ry + 12);
          ctx.stroke();
        }
      }

      // Update & Draw Projectiles (Meteors, Rockets, Lava)
      projectilesRef.current.forEach((proj, idx) => {
        proj.x += proj.vx;
        proj.y += proj.vy;
        if (proj.type === 'meteor' || proj.type === 'lava') {
          proj.vy += 0.25;
        }

        ctx.fillStyle = proj.color;
        ctx.beginPath();
        ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
        ctx.fill();

        // Rocket Trail
        if (proj.type === 'rocket') {
          spawnParticles(proj.x, proj.y, '#f97316', 1);
        }

        // Collision with ground/platforms
        platforms.forEach((plat) => {
          if (
            proj.x > plat.x &&
            proj.x < plat.x + plat.w &&
            proj.y > plat.y &&
            proj.y < plat.y + plat.h
          ) {
            // Explode!
            sounds.playExplosion();
            screenShakeRef.current = 6;
            spawnParticles(proj.x, proj.y, proj.color, 16);
            projectilesRef.current.splice(idx, 1);

            // Splash damage to nearby players
            playersRef.current.forEach((pl) => {
              const dist = Math.hypot(pl.x + 10 - proj.x, pl.y + 20 - proj.y);
              if (dist < 70 && pl.invincibleTimer <= 0) {
                pl.hp -= 40;
                pl.vx = (pl.x - proj.x) * 0.25;
                pl.vy = -6;
                if (pl.hp <= 0 && pl.isAlive) {
                  pl.hp = 0;
                  pl.isAlive = false;
                  sounds.playOof();
                }
              }
            });
          }
        });
      });

      // Update & Draw Particles
      particlesRef.current.forEach((pt, pIdx) => {
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life++;
        const alpha = Math.max(0, 1 - pt.life / pt.maxLife);
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = alpha;
        ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
        ctx.globalAlpha = 1;
        if (pt.life >= pt.maxLife) {
          particlesRef.current.splice(pIdx, 1);
        }
      });

      // Update & Render Players (Local + Bots)
      playersRef.current.forEach((player) => {
        // Invincibility countdown
        if (player.invincibleTimer > 0) player.invincibleTimer--;
        if (player.lungeTimer > 0) player.lungeTimer--;
        if (player.chatTimer > 0) {
          player.chatTimer--;
          if (player.chatTimer <= 0) player.chatBubble = null;
        }

        if (!player.isAlive) {
          // Dead player: draw ragdoll blocks
          drawAvatar(ctx, player, time);
          return;
        }

        // ============================
        // CONTROLS & BOT AI
        // ============================
        if (player.isLocal) {
          const moveLeft = keysRef.current['KeyA'] || keysRef.current['ArrowLeft'] || mobileLeft;
          const moveRight = keysRef.current['KeyD'] || keysRef.current['ArrowRight'] || mobileRight;

          const baseSpeed = player.equippedGear?.type === 'speed_coil' ? 5.8 : 3.4;

          if (moveLeft) {
            player.vx = -baseSpeed;
            player.facing = 'left';
          } else if (moveRight) {
            player.vx = baseSpeed;
            player.facing = 'right';
          } else {
            player.vx *= 0.65;
          }
        } else {
          // Bot AI Behavior
          if (Math.random() < 0.02) {
            player.vx = (Math.random() - 0.5) * 4;
            player.facing = player.vx > 0 ? 'right' : 'left';
          }
          if (Math.random() < 0.015 && player.grounded) {
            player.vy = -10.5;
            player.grounded = false;
          }
          // SFOTH bots chase nearest opponent
          if (mode === 'sfoth') {
            const nearest = playersRef.current.find((other) => other.id !== player.id && other.isAlive);
            if (nearest) {
              const dx = nearest.x - player.x;
              if (Math.abs(dx) > 20) {
                player.vx = dx > 0 ? 3 : -3;
                player.facing = dx > 0 ? 'right' : 'left';
              }
              // Bot sword swings
              if (Math.abs(dx) < 40 && Math.random() < 0.05) {
                player.lungeTimer = 14;
                nearest.hp -= 25;
                sounds.playSwordSlash();
                if (nearest.hp <= 0 && nearest.isAlive) {
                  nearest.hp = 0;
                  nearest.isAlive = false;
                  sounds.playOof();
                }
              }
            }
          }
        }

        // Apply Gravity
        const grav = player.equippedGear?.type === 'gravity_coil' ? 0.24 : 0.55;
        player.vy += grav;

        // Apply Velocities
        player.x += player.vx;
        player.y += player.vy;

        // Platform Collisions (AABB)
        player.grounded = false;

        platforms.forEach((plat) => {
          // Check collision
          const pLeft = player.x;
          const pRight = player.x + player.width;
          const pTop = player.y;
          const pBottom = player.y + player.height;

          const platLeft = plat.x;
          const platRight = plat.x + plat.w;
          const platTop = plat.y;
          const platBottom = plat.y + plat.h;

          if (pRight > platLeft && pLeft < platRight && pBottom >= platTop && pTop < platBottom) {
            if (plat.type === 'kill') {
              // Classic Red Kill Brick collision!
              if (player.invincibleTimer <= 0) {
                player.hp = 0;
                player.isAlive = false;
                sounds.playOof();
                onUnlockBadge('first_oof');
                if (player.isLocal) {
                  setAnnouncement('💀 OOF! You touched a deadly red laser!');
                }
              }
              return;
            }

            if (plat.type === 'bounce') {
              // Trampoline Spring Pad!
              sounds.playCoil();
              player.vy = -16.5;
              player.grounded = false;
              spawnParticles(player.x + 10, platTop, '#eab308', 6);
              return;
            }

            if (plat.type === 'conveyor') {
              player.x += plat.speed || 2;
            }

            // Checkpoint / Golden Vault
            if (plat.type === 'checkpoint' && plat.label === 'VAULT' && player.isLocal) {
              sounds.playWinFanfare();
              confetti({ particleCount: 90, spread: 90, origin: { y: 0.3 } });
              onAddRobux(250);
              onAddWin();
              onUnlockBadge('obby_champ');
              setAnnouncement('🏆 CONGRATULATIONS! You conquered the Tower of Hell! (+250 Robux)');
              onNewChatMessage('SYSTEM', 'You conquered the Tower of Hell! +250 Robux!', '#fbbf24');
              // Teleport to bottom
              player.x = 80;
              player.y = 500;
              return;
            }

            // Solid landing on top
            if (player.vy > 0 && pBottom - player.vy <= platTop + 8) {
              player.y = platTop - player.height;
              player.vy = 0;
              player.grounded = true;
            }
          }
        });

        // Tycoon Button Stepping
        if (mode === 'tycoon' && player.isLocal) {
          const t = tycoonStateRef.current;
          t.buttons.forEach((btn) => {
            if (btn.purchased) return;
            if (
              player.x + player.width > btn.x &&
              player.x < btn.x + btn.w &&
              player.y + player.height >= btn.y &&
              player.y < btn.y + btn.h + 10
            ) {
              if (t.cash >= btn.cost) {
                t.cash -= btn.cost;
                btn.purchased = true;
                sounds.playCoin();
                confetti({ particleCount: 40, spread: 60 });
                onUnlockBadge('tycoon_boss');
                onNewChatMessage('SYSTEM', `Purchased ${btn.title}! Base expanded!`, '#22c55e');

                // Activate perks
                if (btn.id === 'dropper1') {
                  t.droppers.push({ id: 'd1', x: 140, y: 440, interval: 2, lastDrop: 0, value: 10, color: '#22c55e' });
                } else if (btn.id === 'dropper2') {
                  t.droppers.push({ id: 'd2', x: 260, y: 440, interval: 1.5, lastDrop: 0, value: 25, color: '#94a3b8' });
                } else if (btn.id === 'upgrader') {
                  t.multiplier *= 2;
                } else if (btn.id === 'dropper3') {
                  t.droppers.push({ id: 'd3', x: 380, y: 360, interval: 1.2, lastDrop: 0, value: 60, color: '#f59e0b' });
                } else if (btn.id === 'mega_dropper') {
                  t.droppers.push({ id: 'd4', x: 500, y: 360, interval: 0.8, lastDrop: 0, value: 150, color: '#ec4899' });
                  onAddRobux(300);
                }
              }
            }
          });
        }

        // Disaster hazard checks: Flash flood drowning
        if (mode === 'disaster' && disasterRef.current.active?.type === 'flood') {
          if (player.y + player.height > disasterRef.current.waterLevel + 10) {
            player.hp -= 1.2;
            if (player.hp <= 0) {
              player.isAlive = false;
              sounds.playOof();
              if (player.isLocal) setAnnouncement('💀 OOF! You drowned in the toxic flash flood!');
            }
          }
        }

        // Disaster hazard checks: Acid rain exposed damage
        if (mode === 'disaster' && disasterRef.current.active?.type === 'acid_rain') {
          // Check if sheltered by any platform directly above player
          const isSheltered = platforms.some(
            (p) => p.y < player.y && player.x > p.x && player.x < p.x + p.w
          );
          if (!isSheltered) {
            player.hp -= 0.35;
            spawnParticles(player.x + 10, player.y, '#84cc16', 1);
            if (player.hp <= 0) {
              player.isAlive = false;
              sounds.playOof();
              if (player.isLocal) setAnnouncement('💀 OOF! Acid rain dissolved you!');
            }
          }
        }

        // Fall into Void (SFOTH / Obby)
        if (player.y > height + 50) {
          player.hp = 0;
          player.isAlive = false;
          sounds.playOof();
          onUnlockBadge('first_oof');
          if (player.isLocal) {
            setAnnouncement('💀 OOF! You fell into the bottomless void!');
          }
        }

        // Respawn Dead Players after 2.5 seconds
        if (!player.isAlive) {
          setTimeout(() => {
            player.isAlive = true;
            player.hp = player.maxHp;
            player.x = mode === 'obby' ? obbyCheckpointRef.current.x : 100 + Math.random() * 200;
            player.y = 420;
            player.vx = 0;
            player.vy = 0;
            player.invincibleTimer = 90;
          }, 2500);
        }

        // Render Avatar
        drawAvatar(ctx, player, time);
      });

      // Random bot chat generation for lively Roblox ambiance
      botChatTimer++;
      if (botChatTimer > 320) {
        botChatTimer = 0;
        const randomBot = playersRef.current.find((p) => !p.isLocal && p.isAlive);
        if (randomBot) {
          const phrase = CHAT_PHRASES[Math.floor(Math.random() * CHAT_PHRASES.length)];
          randomBot.chatBubble = phrase;
          randomBot.chatTimer = 180;
          onNewChatMessage(randomBot.name, phrase, '#94a3b8');
        }
      }

      ctx.restore(); // Restore shake
      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [mode, getPlatforms, onAddKill, onAddRobux, onAddWin, onUnlockBadge, onNewChatMessage, mobileLeft, mobileRight]);

  // Click on Canvas to Attack or Studio Place
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (mode === 'studio' && !isTestingStudio) {
      sounds.playClick();
      if (studioTool === 'erase') {
        setCustomBricks((prev) =>
          prev.filter((b) => !(x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h))
        );
      } else {
        const snapX = Math.floor(x / 30) * 30;
        const snapY = Math.floor(y / 20) * 20;
        const newBrick: StudioBrick = {
          id: `${Date.now()}_${Math.random()}`,
          x: snapX,
          y: snapY,
          w: studioTool === 'bounce' ? 50 : 60,
          h: 16,
          color: studioTool === 'kill' ? '#ef4444' : studioTool === 'bounce' ? '#eab308' : studioColor,
          type: studioTool === 'kill' ? 'kill' : studioTool === 'bounce' ? 'bounce' : studioTool === 'conveyor' ? 'conveyor' : 'solid',
        };
        setCustomBricks((prev) => [...prev, newBrick]);
        onUnlockBadge('studio_builder');
      }
    } else {
      triggerAction();
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none overflow-hidden">
      {/* Top Disaster/Event Banner Announcement */}
      {announcement && (
        <div className="absolute top-3 inset-x-4 max-w-xl mx-auto z-20 px-4 py-2 bg-amber-500/90 text-neutral-950 font-bold text-xs rounded-xl shadow-lg border border-amber-300 text-center animate-bounce">
          {announcement}
        </div>
      )}

      {/* Mode Specific In-game HUD */}
      {mode === 'disaster' && (
        <div className="absolute top-14 left-4 z-10 flex items-center gap-2 bg-neutral-900/80 backdrop-blur px-3 py-1.5 rounded-lg border border-white/10 text-xs font-semibold text-white">
          <span className="text-amber-400">
            {disasterRef.current.phase === 'intermission' ? 'Next Disaster in:' : 'Survive for:'}
          </span>
          <span className="font-mono text-sm font-bold text-white">
            {Math.ceil(disasterRef.current.phaseTimer)}s
          </span>
        </div>
      )}

      {mode === 'tycoon' && (
        <div className="absolute top-14 left-4 z-10 flex items-center gap-3 bg-neutral-900/85 backdrop-blur px-4 py-2 rounded-xl border border-white/10 shadow-lg text-xs font-bold text-white">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span>Cash:</span>
            <span className="text-sm font-mono">${tycoonStateRef.current.cash.toLocaleString()}</span>
          </div>
          <div className="text-neutral-400">|</div>
          <div className="text-amber-400">
            <span>Multiplier: </span>
            <span className="font-mono">{tycoonStateRef.current.multiplier}x</span>
          </div>
        </div>
      )}

      {/* 2D Studio Sandbox Toolbar */}
      {mode === 'studio' && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 p-1.5 bg-neutral-900/90 backdrop-blur border border-white/15 rounded-xl shadow-xl">
          <button
            onClick={() => setIsTestingStudio(!isTestingStudio)}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
              isTestingStudio ? 'bg-amber-600 text-white' : 'bg-emerald-600 text-white'
            }`}
          >
            {isTestingStudio ? '⏹ Stop Testing' : '▶ Test Play Level'}
          </button>

          {!isTestingStudio && (
            <>
              {(['solid', 'kill', 'bounce', 'conveyor', 'erase'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    sounds.playClick();
                    setStudioTool(t);
                  }}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg capitalize transition-colors ${
                    studioTool === t ? 'bg-sky-600 text-white' : 'bg-neutral-800 text-neutral-300 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}

              <input
                type="color"
                value={studioColor}
                onChange={(e) => setStudioColor(e.target.value)}
                title="Brick Color"
                className="w-7 h-7 rounded border border-white/20 bg-transparent cursor-pointer"
              />

              <button
                onClick={() => {
                  sounds.playClick();
                  setCustomBricks([]);
                }}
                className="px-2 py-1 text-xs text-rose-400 hover:bg-neutral-800 rounded font-semibold"
              >
                Clear
              </button>
            </>
          )}
        </div>
      )}

      {/* Game Canvas */}
      <canvas
        ref={canvasRef}
        width={900}
        height={600}
        onClick={handleCanvasClick}
        className="w-full max-w-[900px] aspect-[3/2] rounded-xl shadow-2xl border border-white/10 bg-slate-900 cursor-crosshair"
      />
    </div>
  );
};

// Helper: Sky rendering based on experience theme
function drawSky(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  mode: GameMode,
  activeDisaster: DisasterEvent | null
) {
  if (activeDisaster) {
    if (activeDisaster.type === 'meteors' || activeDisaster.type === 'volcano') {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, '#450a0a');
      grad.addColorStop(0.6, '#7f1d1d');
      grad.addColorStop(1, '#1c1917');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      return;
    }
    if (activeDisaster.type === 'acid_rain') {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, '#14532d');
      grad.addColorStop(0.7, '#166534');
      grad.addColorStop(1, '#052e16');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      return;
    }
  }

  if (mode === 'disaster') {
    // Sunny Happy Day sky
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#38bdf8');
    grad.addColorStop(0.7, '#7dd3fc');
    grad.addColorStop(1, '#bae6fd');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Fluffy retro clouds
    ctx.fillStyle = '#ffffffbb';
    ctx.beginPath();
    ctx.arc(160, 90, 30, 0, Math.PI * 2);
    ctx.arc(200, 80, 40, 0, Math.PI * 2);
    ctx.arc(240, 90, 30, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.arc(680, 110, 25, 0, Math.PI * 2);
    ctx.arc(710, 100, 35, 0, Math.PI * 2);
    ctx.arc(740, 110, 25, 0, Math.PI * 2);
    ctx.fill();
  } else if (mode === 'obby') {
    // Dark Neon Cyber Void
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#09090b');
    grad.addColorStop(0.6, '#18181b');
    grad.addColorStop(1, '#27272a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Vertical tower neon laser lines
    ctx.strokeStyle = '#ffffff08';
    ctx.lineWidth = 1;
    for (let x = 60; x < w; x += 60) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
  } else if (mode === 'sfoth') {
    // Heights Sky: Sunset over the void
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#1e1b4b');
    grad.addColorStop(0.5, '#4338ca');
    grad.addColorStop(0.8, '#f59e0b');
    grad.addColorStop(1, '#0f172a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  } else {
    // Default studio/tycoon dark slate
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e293b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  }
}
