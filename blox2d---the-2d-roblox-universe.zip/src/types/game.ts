export type GameMode = 'discover' | 'disaster' | 'obby' | 'tycoon' | 'sfoth' | 'studio' | 'avatar_shop';

export interface AvatarConfig {
  skinColor: string; // Head & arms
  torsoColor: string;
  leftLegColor: string;
  rightLegColor: string;
  hat: string; // 'none' | 'visor' | 'valkyrie' | 'dominus' | 'fedora' | 'bacon' | 'horns' | 'crown'
  face: string; // 'smile' | 'winning' | 'chill' | 'epic' | 'evil' | 'happy'
  accessory: string; // 'none' | 'wings' | 'cape' | 'sword_back' | 'noob_pet'
  animStyle: 'classic' | 'ninja' | 'zombie' | 'float';
}

export interface CatalogItem {
  id: string;
  name: string;
  category: 'hat' | 'face' | 'skin' | 'torso' | 'legs' | 'accessory' | 'gear';
  price: number;
  unlocked: boolean;
  value: string;
  description: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary';
  iconColor?: string;
}

export interface GearItem {
  id: string;
  name: string;
  icon: string;
  slot: number;
  type: 'sword' | 'speed_coil' | 'gravity_coil' | 'cola' | 'rocket';
  cooldown: number;
  lastUsed: number;
}

export interface Player {
  id: string;
  name: string;
  isLocal: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  grounded: boolean;
  hp: number;
  maxHp: number;
  avatar: AvatarConfig;
  equippedGear: GearItem | null;
  facing: 'left' | 'right';
  currentEmote: string | null;
  emoteTimer: number;
  chatBubble: string | null;
  chatTimer: number;
  kills: number;
  isAlive: boolean;
  invincibleTimer: number;
  lungeTimer: number;
  walkFrame: number;
}

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  isSystem?: boolean;
  color?: string;
  timestamp: string;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: AvatarConfig;
  robux: number;
  wins: number;
  kills: number;
  ping: number;
  isLocal?: boolean;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

// Studio Brick for 2D Map Editor
export interface StudioBrick {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  type: 'solid' | 'kill' | 'bounce' | 'conveyor' | 'checkpoint' | 'coin';
  speed?: number;
}
