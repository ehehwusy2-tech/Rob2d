import { Player, AvatarConfig } from '../types/game';

/**
 * Draws the iconic 2D Robloxian blocky avatar, accessories, held gear,
 * nametag, and overhead chat bubbles onto the canvas context.
 */
export function drawAvatar(
  ctx: CanvasRenderingContext2D,
  player: Player,
  time: number
) {
  const { x, y, width, height, facing, avatar, hp, maxHp, name, isLocal, chatBubble, isAlive } = player;

  if (!isAlive) {
    // Draw ragdoll / disassembled blocks!
    drawRagdollPieces(ctx, x, y, avatar, time);
    return;
  }

  ctx.save();
  ctx.translate(x + width / 2, y + height);

  // Direction flip
  const flip = facing === 'left' ? -1 : 1;
  ctx.scale(flip, 1);

  // Animation calculation
  const isMoving = Math.abs(player.vx) > 0.4 && player.grounded;
  let legAngle = 0;
  let armAngle = 0;
  let bob = 0;

  if (player.currentEmote === 'dance') {
    legAngle = Math.sin(time * 8) * 0.4;
    armAngle = Math.cos(time * 8) * 0.7;
    bob = Math.abs(Math.sin(time * 8)) * 3;
    ctx.rotate(Math.sin(time * 4) * 0.08);
  } else if (player.currentEmote === 'wave') {
    armAngle = Math.sin(time * 12) * 0.6 - 1.2;
  } else if (player.currentEmote === 'cheer') {
    armAngle = -2.2 + Math.sin(time * 10) * 0.2;
    bob = Math.abs(Math.sin(time * 10)) * 4;
  } else if (!player.grounded) {
    // In air jump pose
    legAngle = -0.3;
    armAngle = -1.2;
    bob = -2;
  } else if (isMoving) {
    legAngle = Math.sin(time * 12) * 0.55;
    armAngle = -legAngle * 0.8;
    bob = Math.abs(Math.sin(time * 12)) * 2;
  }

  // Draw Wings/Cape on back
  if (avatar.accessory === 'wings') {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.5;
    const wingFlap = Math.sin(time * 6) * 4;
    // Left wing
    ctx.beginPath();
    ctx.moveTo(-10, -32 - bob);
    ctx.quadraticCurveTo(-35, -45 + wingFlap, -28, -20);
    ctx.quadraticCurveTo(-20, -15, -6, -24 - bob);
    ctx.fill();
    ctx.stroke();
    // Wing accents
    ctx.fillStyle = '#f1f5f9';
    ctx.beginPath();
    ctx.arc(-22, -30 + wingFlap, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else if (avatar.accessory === 'cape') {
    ctx.save();
    ctx.fillStyle = '#b91c1c';
    const capeFlutter = isMoving ? Math.sin(time * 14) * 6 : Math.sin(time * 4) * 2;
    ctx.beginPath();
    ctx.moveTo(-6, -30 - bob);
    ctx.lineTo(-14 - Math.abs(player.vx) * 3, -10 + capeFlutter);
    ctx.lineTo(-4, -10 + capeFlutter);
    ctx.lineTo(-2, -30 - bob);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // Left Leg (Behind)
  ctx.save();
  ctx.translate(-4, -16);
  ctx.rotate(-legAngle);
  ctx.fillStyle = avatar.leftLegColor;
  ctx.fillRect(-3.5, 0, 7, 16);
  ctx.strokeStyle = '#00000022';
  ctx.strokeRect(-3.5, 0, 7, 16);
  ctx.restore();

  // Right Leg (Front)
  ctx.save();
  ctx.translate(4, -16);
  ctx.rotate(legAngle);
  ctx.fillStyle = avatar.rightLegColor;
  ctx.fillRect(-3.5, 0, 7, 16);
  ctx.strokeStyle = '#00000022';
  ctx.strokeRect(-3.5, 0, 7, 16);
  ctx.restore();

  // Torso
  const torsoY = -34 - bob;
  ctx.save();
  ctx.fillStyle = avatar.torsoColor;
  ctx.fillRect(-9, torsoY, 18, 18);
  ctx.strokeStyle = '#00000025';
  ctx.lineWidth = 1;
  ctx.strokeRect(-9, torsoY, 18, 18);

  // Torso Stud details / Classic R logo or texture
  ctx.fillStyle = '#ffffff25';
  ctx.beginPath();
  ctx.arc(-4, torsoY + 4, 1.5, 0, Math.PI * 2);
  ctx.arc(4, torsoY + 4, 1.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Left Arm (Behind)
  ctx.save();
  ctx.translate(-11, torsoY + 2);
  ctx.rotate(-armAngle);
  ctx.fillStyle = avatar.skinColor;
  ctx.fillRect(-3, 0, 6, 16);
  ctx.strokeStyle = '#00000022';
  ctx.strokeRect(-3, 0, 6, 16);
  ctx.restore();

  // Head
  const headY = torsoY - 14;
  ctx.save();
  ctx.fillStyle = avatar.skinColor;
  ctx.fillRect(-6.5, headY, 13, 13);
  ctx.strokeStyle = '#00000025';
  ctx.strokeRect(-6.5, headY, 13, 13);

  // Head Top Stud
  ctx.fillStyle = avatar.skinColor;
  ctx.fillRect(-3, headY - 2.5, 6, 3);
  ctx.strokeRect(-3, headY - 2.5, 6, 3);

  // Face Expression
  drawFace(ctx, 0, headY + 6.5, avatar.face);

  // Hat
  if (avatar.hat !== 'none') {
    drawHat(ctx, 0, headY, avatar.hat, time);
  }

  ctx.restore();

  // Shoulder Pet
  if (avatar.accessory === 'noob_pet') {
    ctx.save();
    ctx.translate(-11, torsoY - 2);
    // Mini yellow head
    ctx.fillStyle = '#fde047';
    ctx.fillRect(-3, -7, 6, 6);
    // Mini blue torso
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(-3.5, -1, 7, 5);
    // Mini green legs
    ctx.fillStyle = '#16a34a';
    ctx.fillRect(-3, 4, 6, 3);
    // Mini smile
    ctx.fillStyle = '#000';
    ctx.fillRect(-1.5, -5, 1, 1);
    ctx.fillRect(0.5, -5, 1, 1);
    ctx.fillRect(-1, -3, 2, 0.8);
    ctx.restore();
  }

  // Right Arm (Front)
  ctx.save();
  ctx.translate(11, torsoY + 2);

  // If holding gear, adjust right arm pose!
  let heldGearRotation = armAngle;
  if (player.equippedGear) {
    if (player.equippedGear.type === 'sword') {
      heldGearRotation = player.lungeTimer > 0 ? -1.5 : -0.7 + Math.sin(time * 6) * 0.1;
    } else if (player.equippedGear.type === 'rocket') {
      heldGearRotation = -1.3;
    } else if (player.equippedGear.type === 'cola') {
      heldGearRotation = -1.9 + Math.sin(time * 8) * 0.15;
    } else {
      heldGearRotation = -0.5;
    }
  }

  ctx.rotate(heldGearRotation);
  ctx.fillStyle = avatar.skinColor;
  ctx.fillRect(-3, 0, 6, 16);
  ctx.strokeStyle = '#00000022';
  ctx.strokeRect(-3, 0, 6, 16);

  // Held item at hand position
  if (player.equippedGear) {
    drawHeldGear(ctx, 0, 14, player.equippedGear.type, time, player.lungeTimer > 0);
  }

  ctx.restore();

  ctx.restore(); // Restore main transform

  // Draw overhead GUI: Name, Health Bar, Chat Bubble (Unflipped!)
  drawOverheadUI(ctx, x + width / 2, y - 10, name, hp, maxHp, isLocal, chatBubble);
}

function drawFace(ctx: CanvasRenderingContext2D, cx: number, cy: number, face: string) {
  ctx.fillStyle = '#111827';
  if (face === 'winning') {
    // Big winning smile with curved eyes
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = '#111827';
    // Left eye curve
    ctx.beginPath();
    ctx.arc(cx - 2.5, cy - 1.5, 2, Math.PI, 0);
    ctx.stroke();
    // Right eye curve
    ctx.beginPath();
    ctx.arc(cx + 2.5, cy - 1.5, 2, Math.PI, 0);
    ctx.stroke();
    // Huge smile
    ctx.beginPath();
    ctx.arc(cx, cy + 1, 3.5, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.fill();
  } else if (face === 'chill') {
    // Chill shades / chill smile
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(cx - 4.5, cy - 2.5, 9, 3);
    // Smile
    ctx.beginPath();
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 1.2;
    ctx.arc(cx, cy + 2, 2.5, 0.2 * Math.PI, 0.8 * Math.PI);
    ctx.stroke();
  } else if (face === 'epic') {
    // Epic face: massive circular grin
    ctx.beginPath();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#000';
    ctx.arc(cx, cy + 1, 4, 0, Math.PI);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(cx - 2.5, cy - 2, 1.2, 0, Math.PI * 2);
    ctx.arc(cx + 2.5, cy - 2, 1.2, 0, Math.PI * 2);
    ctx.fill();
  } else if (face === 'evil') {
    // Evil slanted eyes & sharp smile
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.moveTo(cx - 4, cy - 3);
    ctx.lineTo(cx - 1, cy - 1);
    ctx.lineTo(cx - 4, cy - 1);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx + 4, cy - 3);
    ctx.lineTo(cx + 1, cy - 1);
    ctx.lineTo(cx + 4, cy - 1);
    ctx.fill();
    // Sharp grin
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx, cy + 1.5, 3, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.stroke();
  } else if (face === 'happy') {
    // Super Super Happy Face
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(cx - 3.5, cy + 1, 1.5, 0, Math.PI * 2);
    ctx.arc(cx + 3.5, cy + 1, 1.5, 0, Math.PI * 2);
    ctx.fill();
    // Big open heart smile
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx, cy + 0.5, 3, 0, Math.PI);
    ctx.stroke();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(cx - 2.5, cy - 2, 1, 0, Math.PI * 2);
    ctx.arc(cx + 2.5, cy - 2, 1, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Classic Roblox default dot eyes and smile
    ctx.fillStyle = '#111827';
    ctx.fillRect(cx - 3, cy - 2.5, 1.5, 1.8);
    ctx.fillRect(cx + 1.5, cy - 2.5, 1.5, 1.8);

    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx, cy + 0.5, 2.6, 0.15 * Math.PI, 0.85 * Math.PI);
    ctx.stroke();
  }
}

function drawHat(ctx: CanvasRenderingContext2D, cx: number, cy: number, hat: string, time: number) {
  if (hat === 'visor') {
    // Classic Red/Blue Visor
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(cx - 7.5, cy + 1, 15, 3.5);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(cx - 2, cy + 1.5, 4, 2);
    // Brim sticking out forward
    ctx.fillStyle = '#2563eb';
    ctx.fillRect(cx + 1, cy + 3.5, 7, 2);
  } else if (hat === 'valkyrie') {
    // Valkyrie Helm (Golden circlet + side wings)
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(cx - 7.5, cy + 1, 15, 3);
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(cx - 2, cy - 1, 4, 3);
    // Side white wings
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(cx - 7, cy + 2);
    ctx.lineTo(cx - 13, cy - 6);
    ctx.lineTo(cx - 6, cy - 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx + 7, cy + 2);
    ctx.lineTo(cx + 13, cy - 6);
    ctx.lineTo(cx + 6, cy - 2);
    ctx.fill();
  } else if (hat === 'dominus') {
    // Dominus Aureus / Infernus Hood
    ctx.fillStyle = '#1e1b4b';
    ctx.beginPath();
    ctx.arc(cx, cy + 4, 9, Math.PI, 0);
    ctx.lineTo(cx + 8, cy + 10);
    ctx.lineTo(cx - 8, cy + 10);
    ctx.closePath();
    ctx.fill();
    // Golden Ring / Feather accents
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(cx - 8.5, cy + 3, 2, 4);
    ctx.fillRect(cx + 6.5, cy + 3, 2, 4);
    // Glowing white eyes inside shroud
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 4;
    ctx.fillRect(cx - 3.5, cy + 5, 2, 1.5);
    ctx.fillRect(cx + 1.5, cy + 5, 2, 1.5);
    ctx.shadowBlur = 0;
  } else if (hat === 'fedora') {
    // Sparkle Time Fedora
    ctx.fillStyle = '#18181b';
    // Brim
    ctx.fillRect(cx - 10, cy + 2, 20, 2.5);
    // Crown
    ctx.fillRect(cx - 6, cy - 4, 12, 6);
    // Blue Ribbon
    ctx.fillStyle = '#06b6d4';
    ctx.fillRect(cx - 6, cy + 0.5, 12, 1.5);
    // Sparkles
    if (Math.sin(time * 6) > 0.5) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(cx - 4, cy - 2, 1.5, 1.5);
      ctx.fillRect(cx + 3, cy - 1, 1.5, 1.5);
    }
  } else if (hat === 'bacon') {
    // Bacon Hair
    ctx.fillStyle = '#92400e';
    ctx.fillRect(cx - 7, cy - 3, 14, 5);
    // Wavy strands
    ctx.fillRect(cx - 8, cy + 1, 4, 6);
    ctx.fillRect(cx + 4, cy + 1, 4, 7);
    ctx.fillStyle = '#b45309';
    ctx.fillRect(cx - 4, cy - 4, 8, 3);
  } else if (hat === 'horns') {
    // Demon Horns
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.moveTo(cx - 5, cy + 1);
    ctx.lineTo(cx - 9, cy - 7);
    ctx.lineTo(cx - 2, cy - 1);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx + 5, cy + 1);
    ctx.lineTo(cx + 9, cy - 7);
    ctx.lineTo(cx + 2, cy - 1);
    ctx.fill();
  } else if (hat === 'crown') {
    // Golden King Crown
    ctx.fillStyle = '#eab308';
    ctx.beginPath();
    ctx.moveTo(cx - 7, cy + 1);
    ctx.lineTo(cx - 7, cy - 5);
    ctx.lineTo(cx - 3.5, cy - 2);
    ctx.lineTo(cx, cy - 6);
    ctx.lineTo(cx + 3.5, cy - 2);
    ctx.lineTo(cx + 7, cy - 5);
    ctx.lineTo(cx + 7, cy + 1);
    ctx.closePath();
    ctx.fill();
    // Rubies
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(cx - 1, cy - 1, 2, 2);
  }
}

function drawHeldGear(
  ctx: CanvasRenderingContext2D,
  gx: number,
  gy: number,
  type: string,
  time: number,
  isLunging: boolean
) {
  ctx.save();
  ctx.translate(gx, gy);

  if (type === 'sword') {
    // Classic Linked Sword
    if (isLunging) {
      // Glow trail during lunge
      ctx.fillStyle = '#38bdf844';
      ctx.fillRect(-2, -28, 4, 28);
    }
    // Hilt / guard
    ctx.fillStyle = '#475569';
    ctx.fillRect(-5, 0, 10, 2.5);
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-1.5, 2.5, 3, 5); // handle
    // Blade
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(-2, -22, 4, 22);
    // Tip
    ctx.beginPath();
    ctx.moveTo(-2, -22);
    ctx.lineTo(0, -26);
    ctx.lineTo(2, -22);
    ctx.fill();
  } else if (type === 'speed_coil') {
    // Blue glowing speed coil
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      ctx.ellipse(0, -i * 5, 6, 2.5, 0, 0, Math.PI * 2);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;
  } else if (type === 'gravity_coil') {
    // Cyan/Purple bouncy gravity coil
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#c084fc';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      ctx.ellipse(0, -i * 5, 7, 3, 0, 0, Math.PI * 2);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;
  } else if (type === 'cola') {
    // Bloxy Cola Can
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-3.5, -10, 7, 10);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-3.5, -6, 7, 2.5); // white stripe
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(-2.5, -11, 5, 1); // silver tab
  } else if (type === 'rocket') {
    // Rocket Launcher
    ctx.fillStyle = '#3f3f46';
    ctx.fillRect(-4, -14, 8, 18);
    ctx.fillStyle = '#ea580c';
    ctx.fillRect(-4, -18, 8, 4); // rocket tip
  }

  ctx.restore();
}

function drawOverheadUI(
  ctx: CanvasRenderingContext2D,
  cx: number,
  topY: number,
  name: string,
  hp: number,
  maxHp: number,
  isLocal: boolean,
  chatBubble: string | null
) {
  // Overhead Name
  ctx.save();
  ctx.font = 'bold 11px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';

  // Text shadow / outline
  ctx.strokeStyle = '#000000ee';
  ctx.lineWidth = 2.5;
  ctx.strokeText(name, cx, topY - 14);
  ctx.fillStyle = isLocal ? '#38bdf8' : '#ffffff';
  ctx.fillText(name, cx, topY - 14);

  // Health Bar (Classic Roblox green/red bar)
  const barW = 28;
  const barH = 4;
  const hpPct = Math.max(0, Math.min(1, hp / maxHp));

  // Background
  ctx.fillStyle = '#000000aa';
  ctx.fillRect(cx - barW / 2 - 1, topY - 12 - 1, barW + 2, barH + 2);

  // Red damage background
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(cx - barW / 2, topY - 12, barW, barH);

  // Green current HP
  ctx.fillStyle = hpPct > 0.3 ? '#22c55e' : '#eab308';
  ctx.fillRect(cx - barW / 2, topY - 12, barW * hpPct, barH);

  // Chat Bubble
  if (chatBubble) {
    ctx.font = '11px Inter, sans-serif';
    const textMetrics = ctx.measureText(chatBubble);
    const bubbleW = Math.max(40, textMetrics.width + 16);
    const bubbleH = 22;
    const bubbleX = cx - bubbleW / 2;
    const bubbleY = topY - 42;

    // Bubble box
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(bubbleX, bubbleY, bubbleW, bubbleH, 6);
    ctx.fill();

    // Bubble pointer down
    ctx.beginPath();
    ctx.moveTo(cx - 4, bubbleY + bubbleH);
    ctx.lineTo(cx, bubbleY + bubbleH + 5);
    ctx.lineTo(cx + 4, bubbleY + bubbleH);
    ctx.fill();

    // Bubble text
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(chatBubble, cx, bubbleY + bubbleH / 2);
  }

  ctx.restore();
}

function drawRagdollPieces(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  avatar: AvatarConfig,
  time: number
) {
  // Scattered Roblox blocks on death
  ctx.save();
  ctx.fillStyle = avatar.skinColor;
  // Head rolling
  ctx.fillRect(x + 2, y + 16, 12, 12);
  // Torso flat
  ctx.fillStyle = avatar.torsoColor;
  ctx.fillRect(x - 14, y + 20, 16, 10);
  // Legs scattered
  ctx.fillStyle = avatar.leftLegColor;
  ctx.fillRect(x + 18, y + 22, 6, 12);
  ctx.fillStyle = avatar.rightLegColor;
  ctx.fillRect(x - 22, y + 23, 10, 6);
  // Arms
  ctx.fillStyle = avatar.skinColor;
  ctx.fillRect(x - 6, y + 24, 8, 5);
  ctx.restore();
}
